import collections,gzip,hashlib,json,re,subprocess,tarfile,xml.etree.ElementTree as E
from pathlib import Path
ROOT=Path('/workspace/issue70');OUT=ROOT/'docs/issue70';TMP=Path('/tmp')
SOURCE='2c06eaad48301a397fb3d802bd74283a491b3e43'
REVIEWED='404ca58f96b3b4cd0b5d8b7af7d69b91189a5f72'
BASE='072baf5f64e07f1d3740c218f348479a2aa858c9'
PR='https://github.com/bohui/copyme2.ai/pull/71'
TARGETS='tests/test_lifetime_semantic_checkpoint.py tests/test_issue70_review_repairs.py tests/test_issue70_strategy_review_repairs.py tests/test_two_lane_memory.py tests/test_interview_strategy.py tests/test_interview_strategy_postgres.py tests/test_interview_strategy_runtime.py tests/test_lifetime_memory_runtime.py tests/test_lifetime_memory_context.py tests/test_lifetime_memory_engine.py tests/test_lifetime_memory_checkpoints.py tests/test_lifetime_memory_service.py tests/test_lifetime_memory_transport.py tests/test_lifetime_memory_publication.py tests/test_lifetime_memory_commit.py tests/test_lifetime_policy_atomic_postgres.py tests/test_lifetime_policy_engine.py tests/test_postgrest_application_conflicts.py tests/test_agent_commit_postgres.py'

def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def records(path):
 rows=[]
 for c in E.parse(path).iter('testcase'):
  status='passed';message=''
  for kind in ('error','failure','skipped'):
   node=c.find(kind)
   if node is not None:
    status={'failure':'failed','error':'error','skipped':'skipped'}[kind];message=node.get('message','');break
  rows.append({'id':c.get('classname')+'::'+c.get('name'),'status':status,'message':message,'seconds':float(c.get('time','0'))})
 return rows

def counts(rows):return {'cases':len(rows),**dict(collections.Counter(r['status'] for r in rows))}
def bad(rows):return {r['id'] for r in rows if r['status'] in ('failed','error')}
def by_id(rows):return {r['id']:r for r in rows}
def seconds(path):return sum(float(n.get('time','0')) for n in E.parse(path).iter('testsuite'))

assert git('rev-parse','HEAD')==SOURCE
assert not git('diff','--name-only',SOURCE,'--','apps','tests','supabase','.env.example')
original=['acceptance.md','architecture-and-benchmark.md','verification.json','case-ledger.json.gz','raw-evidence.tar.gz']
strategy=['strategy-architecture-and-benchmark.md','strategy-acceptance.md','strategy-reproduce.md','strategy-reproduce.py','strategy-verification.json','strategy-case-ledger.json.gz','strategy-raw-evidence.tar.gz']
assert not git('diff','--name-only','9e22d64709176320a6230390e4e3bdf1e91c0a10','--',*[str(Path('docs/issue70')/n) for n in original+strategy])
final=records(TMP/'issue70-semantic-final-aggregate.xml')
previous=json.load(gzip.open(OUT/'strategy-case-ledger.json.gz','rt'))['final_aggregate_records']
intermediate=records(TMP/'issue70-semantic-404ca58-aggregate.xml')
prior_bad=bad(previous);new_bad=bad(final)-prior_bad
previous_map=by_id(previous);final_map=by_id(final)
transitions=[{'id':key,'prior':previous_map[key]['status'],'current':final_map[key]['status']} for key in sorted(previous_map.keys()&final_map.keys()) if previous_map[key]['status']!=final_map[key]['status']]
ledger={'source_head':SOURCE,'base':BASE,'final_aggregate_records':final,'previous_frozen_source':'87478ec1c6d312a3cb23daa1e6883d746fb44154',
 'previous_aggregate_records':previous,'intermediate_404ca58_records':intermediate,'intermediate_404ca58_new_bad_ids':sorted(bad(intermediate)-prior_bad),'new_bad_ids':sorted(new_bad),'status_transitions':transitions,
 'new_case_ids':sorted(final_map.keys()-previous_map.keys()),'missing_prior_ids':sorted(previous_map.keys()-final_map.keys())}
(OUT/'semantic-case-ledger.json.gz').write_bytes(gzip.compress(json.dumps(ledger,ensure_ascii=False,separators=(',',':')).encode(),mtime=0))
raw=sorted(p for p in TMP.glob('issue70-semantic-*') if p.is_file() and p.suffix in ('.xml','.log'))
raw+=[TMP/'issue70-verify.py',TMP/'issue70-build-semantic-evidence.py']
archive=OUT/'semantic-raw-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for path in raw:tar.add(path,arcname='implementation-environment-runner.py' if path.name=='issue70-verify.py' else path.name)
raw_manifest={('implementation-environment-runner.py' if p.name=='issue70-verify.py' else p.name):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in raw}
source_files={f:{'git_blob':git('rev-parse',SOURCE+':'+f),'sha256':sha(ROOT/f)} for f in git('diff','--name-only',BASE,SOURCE).splitlines()
 if f.startswith(('apps/','tests/','supabase/','skills/','scripts/')) or f=='.env.example'}
runs={}
for label,stem,frozen,command in [
 ('frozen-targeted','issue70-semantic-frozen-targeted',True,'python -m pytest -q -n2 --dist=loadfile --timeout=60 --timeout-method=signal '+TARGETS+' --junitxml=/tmp/issue70-semantic-frozen-targeted.xml'),
 ('frozen-capacity','issue70-semantic-frozen-capacity',True,'python -m pytest -q tests/test_lifetime_composer_capacity.py::test_pg_composer_10000_dispositions_have_bounded_complete_root --timeout=60 --timeout-method=signal --tb=short --junitxml=/tmp/issue70-semantic-frozen-capacity.xml'),
 ('final-affected','issue70-semantic-retry-delay-green',False,'python -m pytest -q -n2 --dist=loadfile --timeout=60 --timeout-method=signal tests/test_lifetime_semantic_checkpoint.py tests/test_issue70_review_repairs.py tests/test_progressive_composer.py::test_pg_transient_authority_retry_keeps_originals_and_snapshot_cursor tests/test_lifetime_composer_clearance.py tests/test_lifetime_composer_policy.py --junitxml=/tmp/issue70-semantic-retry-delay-green.xml'),
 ('development-canonical','issue70-semantic-canonical',False,None),
 ('development-photo-commit','issue70-semantic-fence-green',False,None),
 ('development-targeted','issue70-semantic-final-targeted',False,None)]:
 runs[label]={**counts(records(TMP/(stem+'.xml'))),'seconds':seconds(TMP/(stem+'.xml')),'source':REVIEWED if frozen else (SOURCE+' application/migration/test bytes, executed before commit' if label=='final-affected' else 'Development; not a frozen final-source run'),'immutable_source':frozen,'source_bytes_equal_final':label=='final-affected','command':command,'junit':stem+'.xml','log':stem+'.log'}
photo=records(TMP/'issue70-semantic-fence-green.xml')
manifest={'source_head':SOURCE,'base':BASE,'draft_pr':PR,'spec_blob':'50c0458e94b9c2bc9c399720133018594ba426f3','full_issue_acceptance':False,
 'rollout':'Environment/server flags remain OFF; DB defaults disabled/shadow; no production actions',
 'environment':'Sanitized inherited application/provider credentials; disposable native PostgreSQL17; official installed local Temporal CLI; Python3.12.14/pytest9.1.1/Pydantic2.14.1/pytest-xdist3.8.0/pytest-timeout2.4.0; controlled provider transports only',
 'aggregate':{**counts(final),'seconds':seconds(TMP/'issue70-semantic-final-aggregate.xml'),'timing_basis':'JUnit testsuite time; pytest summary is recorded separately','pytest_summary_seconds':float(re.search(r' in ([0-9.]+)s', (TMP/'issue70-semantic-final-aggregate.log').read_text().splitlines()[-1]).group(1)),'source':SOURCE,'immutable_application_migration_test_source':True,
  'command':'python -m pytest -q -n2 --dist=loadfile --timeout=60 --timeout-method=signal --tb=short --junitxml=/tmp/issue70-semantic-final-aggregate.xml','junit':'issue70-semantic-final-aggregate.xml','log':'issue70-semantic-final-aggregate.log'},
 'intermediate_404ca58_aggregate':{**counts(intermediate),'seconds':seconds(TMP/'issue70-semantic-404ca58-aggregate.xml'),'new_bad_ids':sorted(bad(intermediate)-prior_bad),'repair':'Removed redundant11-line deferral override; canonical15-second authority retry is retained','junit':'issue70-semantic-404ca58-aggregate.xml','log':'issue70-semantic-404ca58-aggregate.log'},
 'comparison':{'previous_frozen_source':'87478ec1c6d312a3cb23daa1e6883d746fb44154','previous_counts':counts(previous),'new_bad_ids':sorted(new_bad),'status_transitions':transitions,
  'new_case_ids':sorted(final_map.keys()-previous_map.keys()),'missing_prior_ids':sorted(previous_map.keys()-final_map.keys()),
  'development_photo_failures':sorted(bad(photo)),'development_photo_new_bad_ids':sorted(bad(photo)-prior_bad),
  'note':'Failures/errors/skips retain raw status. A repeated prior failing ID does not itself prove identical root cause. Baseline comparisons and earlier independent review are preserved, not waived.'},
 'supplemental_runs':runs,'javascript':{'passed':530,'failed':0,'skipped':0,'source':REVIEWED,'unchanged_js_and_frontend_test_bytes_at_final':True,'command':'node --test tests/js/*.test.mjs skills/memoir-composer/tests/*.test.mjs tests/historical-news/*.test.mjs','log':'issue70-semantic-js.log'},
 'browser':{'fresh_on_semantic_source':False,'unchanged_frontend_and_browser_test_bytes':True,'prior_passed':6,'prior_source':'strategy stage; synthetic API/auth','evidence':'strategy-raw-evidence.tar.gz:issue70-strategy-browser.xml','limitations':'Not real-model/live auth/uploads/audio/deployment evidence'},
 'tdd':{'meaningful_counterexamples':['issue70-semantic-red2.xml','issue70-semantic-frontier-red.xml','issue70-semantic-pinned-red.xml','issue70-semantic-bound-red.xml','issue70-semantic-policy-red.xml','issue70-semantic-404ca58-aggregate.xml'],
  'note':'All development runs, including fixture/transport mistakes and the initial weaker red, are retained. The development-targeted run had one legacy-lease test-setup failure while test bytes changed; the frozen-targeted run is authoritative. Controlled summaries prove input/output validation and processing, not semantic model quality.'},
 'source_files':source_files,'preserved_prior_evidence':{n:sha(OUT/n) for n in original+strategy},
 'archive':{'file':archive.name,'sha256':sha(archive),'members':raw_manifest},'case_ledger':{'file':'semantic-case-ledger.json.gz','sha256':sha(OUT/'semantic-case-ledger.json.gz')},
 'independent_review':{'source_head':REVIEWED,'reported_by':'Parent delegation on2026-10-16; raw review files are not assumed to be in this workspace','result':'No new actionable defect established in reported review scope; subsequent404ca58 aggregate found one retry-delay regression, repaired at2c06eaa','runs_reported':[{'scope':'semantic/strategy/policy','passed':180},{'scope':'context/transport','passed':196},{'scope':'boundary/repair probes','passed':13},{'scope':'prior repairs','passed':6,'obsolete_expectations_deselected':2}],'counts_overlap':True,'additional_probes':'Crash takeover, empty-output advancement, stale dependencies and account isolation pass','remaining':'Subsequent404ca58 aggregate found the retry regression; the2c06eaa repair review is recorded separately'},
 'independent_retry_delta_review':{'source_head':SOURCE,'reported_by':'Parent delegation on2026-10-16; independent raw files remain with parent','result':'No new actionable finding','delta':'Sole11-line redundant SQL override removal','verified':'Native15-second transient-authority retry, five-minute other delays, partial summary progress, single-owner deferral and stale-token rejection','runs_reported':[{'scope':'semantic/retry/policy','passed':52},{'scope':'boundary/earlier probes','passed':19},{'scope':'prior repair/coalescing','passed':12}],'superseded_probes_deselected':2,'counts_overlap':True},
 'unrun_and_release_gates':['Matched authorized funded live semantic retention/interview quality and latency campaign; exact total cost ceiling absent',
 'Actual provider usage/cost/audio and provider-wide quota/capacity across replicas',
 'Verification of the final evidence-only head and disposition of failed/error/skipped aggregate cases; both404ca58 and the2c06eaa retry delta were independently reviewed as reported',
 'Applicable rollout/production migration/deployment/merge approvals; none implied'],
 'budget':'All semantic maintenance calls and repairs count against the existing frozen540-call B ceiling; no implicit increase or live dispatch',
 'local_semantic_cases':len([r for r in final if r['id'].startswith('tests.test_lifetime_semantic_checkpoint::')])}
(OUT/'semantic-verification.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'source':SOURCE,'aggregate':manifest['aggregate'],'new_bad_ids':sorted(new_bad),'transitions':transitions,'raw_members':len(raw)},indent=2))
