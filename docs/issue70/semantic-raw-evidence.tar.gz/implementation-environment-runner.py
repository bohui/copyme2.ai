import os,subprocess,sys
base='/workspace/copyme2.ai/.venv/bin'
env={k:os.environ[k] for k in ['HOME','LANG','TZ','TMPDIR'] if k in os.environ}
env.update(PATH=base+':/workspace/.tools/postgresql/usr/lib/postgresql/17/bin:/workspace/.tools/temporal:'+os.environ['PATH'],
 PYTHONPATH='/tmp/issue70-testdeps',LD_LIBRARY_PATH='/workspace/.tools/postgresql/usr/lib/x86_64-linux-gnu',
 MEMOIR_TEST_TEMPORAL_CLI='/workspace/.tools/temporal/temporal',MEMORY_SPARK_TEST_MODE='1',MEMOIR_TEST_POSTGRES_BACKEND='native',NO_COLOR='1')
raise SystemExit(subprocess.call(sys.argv[1:],env=env))
