import json,os,subprocess,sys
from pathlib import Path

root=Path('/workspace/memoir-baseline')
name=sys.argv[1]
base=json.loads((root/'docs/test-evidence/memoir-baseline-review-four-20261015.json').read_text())
checks={
 'capacity':(['python','-m','pytest','-q',*[c['nodeid'] for c in base['capacity_reruns']['cases']],
    '--timeout=600','--timeout-method=signal','--tb=short','--junitxml=/tmp/memoir-cloud-current-capacity.xml'],5400,root),
 'javascript':(['node','--test',*map(str,sorted(root.glob('tests/js/*.test.mjs'))),
    *map(str,sorted(root.glob('tests/historical-news/*.test.mjs'))),
    *map(str,sorted(root.glob('skills/memoir-composer/tests/*.test.mjs')))],1200,root),
 'mobile':(['npm','run','check:mobile'],1800,root),
 'mobile-export':(['npm','run','build:mobile'],1800,root),
 'mobile-export-offline':(['npm','run','build:mobile'],1800,root),
 'web-build':(['npm','run','build','--','--webpack'],1800,root/'apps/web'),
 'acceptance':(['python','-m','pytest','-q',*sorted({c['nodeid'].split('::')[0] for c in base['specification_acceptance']['cases']}),
    '--timeout=180','--tb=short','--junitxml=/tmp/memoir-cloud-current-acceptance.xml'],1200,root),
 'localization':(['python','scripts/check_localization_catalog.py'],300,root),
 'routes':(['python','scripts/audit_spec_routes.py','--spec','docs/Memory_Spark_Full_Specification_v1.0.md'],300,root),
 'browser-standalone':(['python','/tmp/run_memoir_cloud_current_browser.py'],1800,root),
 'javascript-lint':([str(root/'node_modules/.bin/eslint'),*subprocess.check_output(['git','diff','--name-only','46caa5fc2c2c5af2d4f7280bea74cc75184c9cbc','HEAD','--','*.js','*.mjs','*.cjs'],cwd=root,text=True).splitlines()],300,root),
}
command,timeout,cwd=checks[name]
prefix=['env','PYTHONPATH=/tmp/memoir-test-tools:.',
 'LD_LIBRARY_PATH=/workspace/.tools/postgresql/usr/lib/x86_64-linux-gnu',
 'MEMOIR_TEST_TEMPORAL_CLI=/workspace/.tools/temporal/temporal','PYTHONHASHSEED=0',
 'EXPO_OFFLINE=1','EXPO_NO_TELEMETRY=1','NPM_CONFIG_UPDATE_NOTIFIER=false']
if cwd!=root:
 command=['python','-c','import os,sys; os.chdir(sys.argv[1]); os.execvp(sys.argv[2],sys.argv[2:])',str(cwd),*command]
args=['python',str(root/'scripts/run_isolated_check.py'),'--root',str(root),
 '--output-dir','/tmp/memoir-cloud-current-receipts','--name',name,'--timeout',str(timeout),'--',*prefix,*command]
code=subprocess.call(args,cwd=root)
print(json.dumps(dict(name=name,exit_code=code)))
raise SystemExit(code)
