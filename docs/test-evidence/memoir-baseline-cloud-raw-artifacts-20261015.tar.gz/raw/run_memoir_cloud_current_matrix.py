import json,subprocess
from pathlib import Path

root=Path('/workspace/memoir-baseline');results=[]
for name in ['javascript','mobile','web-build','mobile-export','acceptance','localization','routes']:
    with Path('/tmp/memoir-cloud-current-'+name+'-supervisor.log').open('w') as stream:
        code=subprocess.call(['python','/tmp/run_memoir_cloud_current_check.py',name],cwd=root,stdout=stream,stderr=subprocess.STDOUT)
    results.append(dict(name=name,supervisor_exit=code))
    Path('/tmp/memoir-cloud-current-matrix-progress.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps(results[-1]),flush=True)
