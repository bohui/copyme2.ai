import http.server,json,os,runpy,shutil,socket,subprocess,sys,threading,time
from pathlib import Path
from urllib.parse import urlsplit

root=Path('/workspace/memoir-baseline');web=root/'apps/web'
backend_requests=[]
class Boundary(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        backend_requests.append(dict(method=self.command,path=urlsplit(self.path).path))
        value=b'{"detail":"Unhandled synthetic backend boundary"}'
        self.send_response(503);self.send_header('Content-Type','application/json')
        self.send_header('Content-Length',str(len(value)));self.end_headers();self.wfile.write(value)
    do_POST=do_GET;do_PATCH=do_GET;do_DELETE=do_GET;do_PUT=do_GET;do_OPTIONS=do_GET
    def log_message(self,*args):pass
backend=http.server.ThreadingHTTPServer(('127.0.0.1',0),Boundary)
threading.Thread(target=backend.serve_forever,daemon=True).start()
with socket.socket() as reservation:
    reservation.bind(('127.0.0.1',0));port=reservation.getsockname()[1]
api=f'http://127.0.0.1:{backend.server_port}';base=f'http://127.0.0.1:{port}'
env=dict(os.environ,MEMORY_SPARK_API_ORIGIN=api,NEXT_TELEMETRY_DISABLED='1',NPM_CONFIG_UPDATE_NOTIFIER='false')
phases=dict(owned_frontend=base,owned_synthetic_backend=api,backend_behavior='Always 503; no catchall success or external dispatch')
server=None;code=2
try:
    with Path('/tmp/memoir-cloud-current-browser-build.log').open('w') as stream:
        build=subprocess.run(['npm','run','build','--','--webpack'],cwd=web,env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=900)
    phases['build_returncode']=build.returncode
    assert build.returncode==0
    standalone=web/'.next/standalone/apps/web'
    shutil.copytree(web/'public',standalone/'public',dirs_exist_ok=True)
    shutil.copytree(web/'.next/static',standalone/'.next/static',dirs_exist_ok=True)
    with Path('/tmp/memoir-cloud-current-browser-server.log').open('w') as stream:
        server=subprocess.Popen(['node',str(standalone/'server.js')],cwd=standalone,
            env=dict(env,HOSTNAME='127.0.0.1',PORT=str(port)),stdout=stream,stderr=subprocess.STDOUT)
    phases['server_pid']=server.pid
    deadline=time.monotonic()+30
    while True:
        assert server.poll() is None,'Task frontend exited before readiness'
        if 'Ready in' in Path('/tmp/memoir-cloud-current-browser-server.log').read_text():break
        assert time.monotonic()<deadline,'Task frontend readiness was not observed'
        time.sleep(.05)
    os.environ.update(MEMOIR_BROWSER_URL=base,MEMORY_SPARK_API_ORIGIN=api,
        MEMOIR_BROWSER_EXECUTABLE='/usr/bin/chromium',MEMOIR_BROWSER_PROFILE_FIXTURE='1')
    scope=runpy.run_path(str(root/'tests/fixtures/browser_network_guard.py'),run_name='controlled_browser_boundary')
    # This aggregate uses only owned loopback services; no public CDN reads.
    scope['public_assets'].clear()
    import pytest
    code=pytest.main(['-q','tests/test_stage_readiness_browser.py','tests/test_browser_collection_fixture.py',
        'tests/test_browser_supabase_fixture.py','tests/test_browser_recovery_fixture.py','--timeout=180','--tb=short',
        '--junitxml=/tmp/memoir-cloud-current-browser.xml'])
    phases['pytest_exit']=int(code)
    Path('/tmp/memoir-cloud-current-browser-network.json').write_text(json.dumps(dict(
        allowed_origins=sorted(scope['origins']),public_read_asset_hosts=sorted(scope['public_assets']),
        blocked=scope['blocked'],synthetic_backend_requests=backend_requests),indent=2)+'\n')
finally:
    if server is not None:
        if server.poll() is None:
            server.terminate()
            try:server.wait(timeout=10)
            except subprocess.TimeoutExpired:server.kill();server.wait(timeout=5)
        phases['server_returncode']=server.returncode
        try:os.kill(server.pid,0)
        except ProcessLookupError:phases['server_reaped']=True
        else:raise AssertionError('Task frontend PID was not reaped')
    backend.shutdown();backend.server_close()
    phases['backend_closed']=True
    Path('/tmp/memoir-cloud-current-browser-phases.json').write_text(json.dumps(phases,indent=2)+'\n')
raise SystemExit(code)
