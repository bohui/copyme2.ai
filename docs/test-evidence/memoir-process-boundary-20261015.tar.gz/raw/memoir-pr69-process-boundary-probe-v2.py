"""Bounded, identity-checked diagnostics; never infer the lost aggregate PID."""
import ast
import asyncio
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

from scripts import single_collector_observation as mode

ROOT=Path('/workspace/memoir-baseline')
OUT=Path('/tmp/memoir-pr69-process-boundary-evidence-v2')
source=ROOT/'tests/test_single_collector_process.py'
tree=ast.parse(source.read_text())
CHILD=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign)
    and any(isinstance(t,ast.Name) and t.id=='CHILD' for t in n.targets))
original_popen=subprocess.Popen
original_killpg=os.killpg
owned={}
current_case=None
signals=[]
receipt_transitions=[]
read_receipt=mode._read_receipt

def identity(pid):
    try:
        p=Path('/proc')/str(pid)
        fields=(p/'stat').read_text().rsplit(') ',1)[1].split()
        return dict(pid=pid,ppid=int(fields[1]),pgid=int(fields[2]),sid=int(fields[3]),
            birth_ticks=fields[19],uid=p.stat().st_uid,state=fields[0])
    except (FileNotFoundError,ProcessLookupError):
        return None

def spawn(*args,**kwargs):
    process=original_popen(*args,**kwargs)
    if kwargs.get('start_new_session'):
        birth=identity(process.pid)
        assert birth and birth['pgid']==birth['sid']==process.pid and birth['uid']==os.getuid()
        owned[process.pid]=dict(case=current_case,birth=birth,process=process)
    return process

def guarded_signal(pgid,sig):
    record=owned.get(pgid)
    if sig:
        now=identity(pgid)
        verified=bool(record and now and now['birth_ticks']==record['birth']['birth_ticks']
            and now['pgid']==now['sid']==pgid and now['uid']==record['birth']['uid'])
        signals.append(dict(case=current_case,pgid=pgid,signal=int(sig),identity_verified=verified,
            identity_at_signal=now,monotonic=time.monotonic()))
        if not verified:
            raise RuntimeError('No signal sent: original owned identity cannot be verified')
    return original_killpg(pgid,sig)

def observe_receipt(directory,plan):
    value=read_receipt(directory,plan)
    if value:
        item=dict(case=current_case,monotonic=time.monotonic(),status=value.get('status'),
            cleanup_complete=value.get('cleanup_complete'),cleanup_started=value.get('cleanup_started_monotonic'))
        key=(item['case'],item['status'],item['cleanup_complete'],item['cleanup_started'])
        if not receipt_transitions or key!=receipt_transitions[-1]['key']:
            receipt_transitions.append(dict(key=key,**item))
    return value

results=[]
subprocess.Popen=spawn
os.killpg=guarded_signal
mode._read_receipt=observe_receipt
try:
    for name in ['unchanged_complete','completed_receipt_with_live_exit_tail','startup_exceeds_execution_budget']:
        current_case=name
        directory=OUT/name
        directory.mkdir(exist_ok=False)
        child=CHILD
        if name=='completed_receipt_with_live_exit_tail':
            child += "\n(directory/'exit-tail-started').write_text('owned synthetic process still alive')\ntime.sleep(.7)\n"
        elif name=='startup_exceeds_execution_budget':
            child="import time;time.sleep(2.3)\n"+child
        (directory/'child.py').write_text(child)
        payload=dict(directory=str(directory),case='complete',api_key='synthetic-private-token',
            plan=dict(run_id='synthetic-run',source_revision='a'*40))
        started=time.monotonic()
        result=asyncio.run(mode._supervise([sys.executable,'-B','-c',child],payload,directory,
            execution_seconds=2,cleanup_seconds=.4,stop_grace=.1))
        rows=[(pid,r) for pid,r in owned.items() if r['case']==name]
        assert len(rows)==1
        pid,record=rows[0]
        process=record['process']
        after=identity(pid)
        reaped=process.poll() is not None
        try:
            os.waitpid(pid,os.WNOHANG)
            wait_status='unexpected-child-still-waitable'
        except ChildProcessError:
            wait_status='not-waitable-already-reaped'
        row=dict(case=name,seconds=time.monotonic()-started,budgets=dict(execution=2,cleanup=.4,stop_grace=.1),
            child_sha256=hashlib.sha256(child.encode()).hexdigest(),original_identity=record['birth'],
            receipt=result,returncode=process.returncode,identity_after_return=after,
            leader_reaped=reaped,waitpid_check=wait_status,exit_tail_marker=(directory/'exit-tail-started').exists())
        results.append(row)
        (directory/'probe-result.json').write_text(json.dumps(row,indent=2)+'\n')
        assert after is None and reaped and wait_status=='not-waitable-already-reaped'
        assert result['process_supervision']['owned_group_gone'] and result['process_supervision']['leader_reaped']
        if name=='unchanged_complete':
            assert result['status']=='observation' and result['cleanup_complete']
        elif name=='completed_receipt_with_live_exit_tail':
            assert row['exit_tail_marker'] and result['status']=='incomplete' and result['cleanup_limit_reached']
            assert result['process_supervision']['forced_stop']
        else:
            assert result['status']=='incomplete' and result['observation']['outcome']=='execution_limit'
finally:
    subprocess.Popen=original_popen
    os.killpg=original_killpg
    mode._read_receipt=read_receipt
    document=dict(schema_version=1,source_file=str(source.relative_to(ROOT)),source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
        source_of_original_child='Read existing committed CHILD fixture; no lost aggregate receipt or identity reconstructed.',
        cases=results,signals=signals,receipt_transitions=receipt_transitions,
        scope='New synthetic owned children only. No listeners/databases/leases/providers or arbitrary PID signalling. Native production budgets are unchanged.',
        limit='Reproduces tooling boundaries only. Does not establish the cause or cleanup of the original0.898s aggregate failure.')
    (OUT/'probe.json').write_text(json.dumps(document,indent=2)+'\n')
print(json.dumps(dict(cases=[dict(case=r['case'],seconds=r['seconds'],status=r['receipt']['status'],
    cleanup_complete=r['receipt']['cleanup_complete'],forced_stop=r['receipt']['process_supervision']['forced_stop'],
    reaped=r['leader_reaped']) for r in results],nonzero_signals=len(signals),all_signals_identity_verified=all(s['identity_verified'] for s in signals)),indent=2))
