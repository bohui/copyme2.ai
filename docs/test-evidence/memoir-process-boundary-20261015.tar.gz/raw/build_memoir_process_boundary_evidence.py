from pathlib import Path
import datetime,gzip,hashlib,io,json,re,subprocess,tarfile

ROOT=Path('/workspace/memoir-baseline')
OUT=ROOT/'docs/test-evidence'
BASE='memoir-process-boundary-20261015'
V1=Path('/tmp/memoir-pr69-process-boundary-evidence')
V2=Path('/tmp/memoir-pr69-process-boundary-evidence-v2')
def load(path):return json.loads(Path(path).read_text())
def digest(value):return hashlib.sha256(value).hexdigest()

def build():
    head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
    assert head=='afb20289a051f929162ba5f8facab3752aa093df'
    original=load(V1/'original-failure.json');inspection=load(V1/'original-inspection.json')
    assert inspection['original_child_identity_found'] is False and inspection['original_child_receipt_found'] is False
    assert original['attributes']['time']=='0.898'
    exact=load(V2/'probe.json');preliminary=load(V1/'probe.json')
    for probe in [exact,preliminary]:
        assert len(probe['cases'])==3 and len(probe['signals'])==2
        assert all(s['identity_verified'] for s in probe['signals'])
        for case in probe['cases']:
            assert case['budgets']==dict(execution=2,cleanup=.4,stop_grace=.1)
            assert case['identity_after_return'] is None and case['leader_reaped']
            assert case['waitpid_check']=='not-waitable-already-reaped'
            assert case['receipt']['process_supervision']['owned_group_gone']
    for directory,helper in [(V1,Path('/tmp/memoir-pr69-process-boundary-probe.py')),
                             (V2,Path('/tmp/memoir-pr69-process-boundary-probe-v2.py'))]:
        start=load(directory/'probe-start.json');expected=start.get('helper_sha256') or start['sha256']
        assert digest(helper.read_bytes())==expected
    prior=load(OUT/'memoir-baseline-repair-20261015.json')
    assert prior['full_python']['current_counts']==dict(passed=5517,failed=574,skipped=259,error=21)
    assert prior['full_python']['classification_categories']['aggregate_case_time_budget']==5
    prior_hashes={}
    for suffix in ['md','json','tar.gz']:
        p=OUT/f'memoir-baseline-repair-20261015.{suffix}';b=p.read_bytes()
        assert b==subprocess.check_output(['git','show',head+':'+str(p.relative_to(ROOT))],cwd=ROOT)
        prior_hashes[str(p.relative_to(ROOT))]=digest(b)
    files={p for directory in [V1,V2] for p in directory.rglob('*') if p.is_file() and not p.is_symlink()}
    files.update([Path('/tmp/memoir-pr69-process-boundary-probe.py'),Path('/tmp/memoir-pr69-process-boundary-probe-v2.py'),
        Path('/tmp/memoir-pr69-process-boundary-supervisor.log'),Path('/tmp/memoir-pr69-process-boundary-v2-supervisor.log'),Path(__file__)])
    artifacts=[];values={}
    token=re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|\bgh[pousr]_[A-Za-z0-9]{20,}|\bsk-(?:proj-)?[A-Za-z0-9_-]{24,}|\bAKIA[0-9A-Z]{16}')
    for p in sorted(files):
        value=p.read_bytes();assert not token.search(value),str(p)
        member='raw/'+str(p.relative_to('/tmp'));values[member]=value
        artifacts.append(dict(original_path=str(p),member=member,bytes=len(value),sha256=digest(value),redacted=False))
    archive=OUT/(BASE+'.tar.gz')
    with archive.open('wb') as stream,gzip.GzipFile(fileobj=stream,mode='wb',mtime=0) as zipped,tarfile.open(fileobj=zipped,mode='w') as tar:
        for member,value in values.items():
            info=tarfile.TarInfo(member);info.size=len(value);info.mode=0o644;tar.addfile(info,io.BytesIO(value))
    with tarfile.open(archive) as tar:
        assert len(tar.getmembers())==len(artifacts)
        for item in artifacts:
            value=tar.extractfile(item['member']).read();assert value==Path(item['original_path']).read_bytes();assert digest(value)==item['sha256']
    result=dict(schema_version=1,repository='bohui/copyme2.ai',pull_request=69,date='2026-10-15',inspected_source_head=head,
        application_tested_head='9a89c4961b2448d8243c39fccdf1a66bc0b00edb',created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        original_failure=original,original_inspection=inspection,original_log_inspection=load(V1/'original-log-inspection.json'),
        unchanged_full_aggregate=dict(counts=prior['full_python']['current_counts'],records=6371,unmet_failures_and_errors=595,aggregate_budget_failures=5,rerun=False),
        preliminary_file_launch=preliminary,exact_original_dash_c_launch=exact,
        native_scope='Six new synthetic child processes, no listeners/databases/leases/model calls. Four nonzero signals each verified against captured PID birth ticks, UID, PGID and SID immediately before dispatch. Every new child reaped and exact child PID absent at return. Not a global PID-absence claim.',
        finding='A complete child receipt does not establish process exit. With original2/.4/.1budgets, a0.7s post-receipt live exit tail deterministically causes incomplete through the cleanup deadline while still safely stopping/reaping the owned process. Startup delay is a distinct execution-limit boundary.',
        classification='Original aggregate failure remains unresolved_process_observation_failure. The0.898s duration is below2s execution budget and is consistent with a cleanup-boundary candidate, but does not prove it.',
        exact_blocker='Original child receipt and owned-child PID/birth/session identity are missing. Outer pytest group1094789 is not the separately sessionized child. Original cause and original child cleanup cannot be verified retroactively. No original or unverified PID guessed/signalled and no lost evidence reconstructed.',
        unchanged_production_and_test_sources=True,prior_evidence_hashes=prior_hashes,
        archive=dict(path=str(archive.relative_to(ROOT)),regular_files=len(artifacts),bytes=archive.stat().st_size,sha256=digest(archive.read_bytes()),readback_exact_matches=len(artifacts),artifacts=artifacts),
        sensitivity_review='Only synthetic test data, local process identities, exact repository source and task-owned logs. Common provider/private-key pattern scan found none; limited scan, not a universal credential detector. No redactions.',
        limits=['No production code or test assertion/budget changed.','No full aggregate rerun; no passing probe waives the original failure or any of five aggregate budget failures.','No product-policy decision, merge to main, deployment, real-user data or provider execution.'])
    (OUT/(BASE+'.json')).write_text(json.dumps(result,indent=2)+'\n')
    rows='\n'.join(f"| {c['case']} | {c['seconds']:.3f}s | `{c['receipt']['status']}` | {c['receipt']['process_supervision']['forced_stop']} | {c['leader_reaped']} |" for c in exact['cases'])
    md=f'''# PR69: bounded process-observation investigation

Inspected head `{head}`; application/test source remains identical to reviewed
`9a89c4961b2448d8243c39fccdf1a66bc0b00edb`. This delivery adds evidence only.
The full aggregate is **not rerun**: **5,517 passed / 574 failed / 21 errors /
259 skipped**, including all **five aggregate budget failures**, remain unchanged.

The original failure is XML record4771,
`tests/test_single_collector_process.py::test_completed_process_is_reaped_before_receipt_return`
at line98. Its duration is **0.898s**; its only saved failure details are
`incomplete` versus expected `observation`. The exact original full-log section,
parsed XML fields, outer runner receipt and prior receipt search are packaged.
The original child was launched in a separate session with stdout/stderr discarded.
Neither its child receipt nor its owned PID/birth/session identity survives in
the preserved evidence or task-owned pytest paths. Outer pytest group1094789
does not identify that child. **The original cause and that child's cleanup remain
unestablished.** No original or unverified PID is guessed or signalled, and no lost receipt is reconstructed.

## Bounded diagnostic

New runs use the existing committed `CHILD` fixture, original **2s execution /
0.4s cleanup / 0.1s stop-grace** budgets, and the exact original `python -B -c`
launch shape. Only explicitly labelled child variants add a controlled delay.
A preliminary file-launch version is also retained separately.

| Exact-launch case | Elapsed | Result | Forced stop | Reaped |
| --- | ---: | --- | --- | --- |
{rows}

The live-exit-tail case writes a completed receipt, then keeps that same owned
process alive for0.7s. Recorded transitions show `observation/cleanup_complete=true`
while the process is still alive. The supervisor correctly returns `incomplete`
when its shorter cleanup deadline expires, force-stops the exact owned process,
and reaps it. Thus a sub-second `incomplete` can arise from the cleanup boundary
without reaching the2s execution limit. The startup-delay control instead reports
`execution_limit` after approximately2s. This diagnoses the tooling boundary;
it does **not** establish which path occurred in the lost original failure.

Across both diagnostic versions, **six new children** were reaped. All **four
nonzero signals** were verified against recorded PID birth ticks, UID, PGID and
SID immediately before dispatch; each result records group absence, reaping,
and `waitpid` finding no remaining waitable child. These statements concern the
new recorded identities only, not the lost aggregate child or unrelated processes.

## Exact remaining blocker

The missing original receipt and owned-child identity prevent retrospective
verification of cause and cleanup. A new passing focused run cannot repair that
evidence gap. Classification stays **unresolved process-observation failure**;
no timing/environment/preexisting attribution is assumed. Production supervision,
test assertions, budgets and product policies are unchanged. No expensive
aggregate was repeated merely to seek a pass.

[Manifest, process identities, transitions and limits]({BASE}.json) ·
[Lossless raw evidence and exact diagnostic helper versions]({BASE}.tar.gz).
The archive has **{len(artifacts)} regular files**, {archive.stat().st_size:,} bytes,
SHA256 `{digest(archive.read_bytes())}`. Every member was read back and matched
byte-for-byte/hash. The prior150-file archive and report are unchanged. No original
child evidence was reconstructed; extracted original log bytes and parsed XML
representations are explicitly distinguished.

Only disposable synthetic processes were used; no listeners, databases, leases,
providers, real data, access changes, product-policy choices, merge to main or
deployment occurred. Human ready-for-review status remains preserved; acceptance
is incomplete.
'''
    for a,b in [('record4771','record 4771'),('line98','line 98'),('group1094789','group 1094789'),('for0.7s','for 0.7s'),('the2s','the 2s'),('approximately2s','approximately 2s'),('prior150','prior 150')]:md=md.replace(a,b)
    (OUT/(BASE+'.md')).write_text(md)
    print(json.dumps(dict(files=len(artifacts),archive_sha256=result['archive']['sha256'],original_failure_unresolved=True,new_owned_children=6,nonzero_signals_verified=4),indent=2))

if __name__=='__main__':build()
