
import asyncio, json, signal, sys, threading, time
from pathlib import Path
from scripts.issue14_subscription_runner import _settle_task
value=json.load(sys.stdin)
directory=Path(value['directory'])
receipt={'run_id':value['plan']['run_id'],'source_revision':value['plan']['source_revision'],
    'status':'observation','observation':{'outcome':'collector_completed','campaign_acceptance':False},
    'native':{'cleanup_complete':False},'cleanup_complete':False,
    'request_accounting':{'client_requests_started':3,'completed_http_responses':2,
        'unresolved_requests':1,'closed':True,'stop_reason':'closed'}}
def save(name, value):
    temporary=directory/(name+'.tmp')
    temporary.write_text(json.dumps(value))
    temporary.replace(directory/name)
async def run():
    if value['case']=='timeout_hang':receipt['observation']['outcome']='worker_timeout'
    root=asyncio.current_task()
    signals=[]
    def cancel():
        signals.append('term')
        save('signals.json',signals)
        root.cancel()
    asyncio.get_running_loop().add_signal_handler(signal.SIGTERM,cancel)
    # This is the real cancellation-suppressing join, including a live thread.
    hold=threading.Event()
    task=asyncio.create_task(asyncio.to_thread(hold.wait))
    try:
        if value['case']=='setup_hang':await asyncio.shield(task)
    except asyncio.CancelledError:
        receipt.update(status='incomplete',cancelled=True)
        receipt['observation']['outcome']='cancelled'
    finally:
        receipt['cleanup_started_monotonic']=time.monotonic()
        save('receipt.json',receipt)
        if value['case']=='complete':
            hold.set()
        await _settle_task(task)
        receipt['native']['cleanup_complete']=receipt['cleanup_complete']=True
        save('receipt.json',receipt)
        (directory/'late-write').write_text('cleanup completed')
asyncio.run(run())

(directory/'exit-tail-started').write_text('owned synthetic process still alive')
time.sleep(.7)
