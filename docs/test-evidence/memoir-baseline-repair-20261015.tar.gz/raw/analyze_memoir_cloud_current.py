from pathlib import Path
import collections,hashlib,json,re,subprocess,xml.etree.ElementTree as E

ROOT=Path('/workspace/memoir-baseline')
HEAD='b4e184c8ad2568b6c671b0f6ea22b0ae404b8afb'
SOURCE='51ca7fe5629f74f6a657a7a2e611d86dabf91bf8'
BASE='b1e54e8e65bbb0facc1edeb2d2bb90db99212788'
HIST=ROOT/'docs/test-evidence/memoir-baseline-review-four-20261015.json'

def read(path):
    document=E.parse(path).getroot();records=[]
    for index,t in enumerate(document.iter('testcase')):
        problems=[dict(kind=p.tag,message=p.get('message',''),text=p.text or '',attributes=p.attrib)
            for p in t if p.tag in {'failure','error','skipped'}]
        status=('failed' if any(p['kind']=='failure' for p in problems) else
            'error' if any(p['kind']=='error' for p in problems) else
            'skipped' if any(p['kind']=='skipped' for p in problems) else 'passed')
        nodeid=(t.get('classname','').replace('.','/')+'.py::'+t.get('name',''))
        records.append(dict(record_index=index,nodeid=nodeid,outcome=status,seconds=float(t.get('time','0')),
            problems=problems,attributes=t.attrib))
    counts=dict(collections.Counter(r['outcome'] for r in records))
    return dict(counts=counts,collected_records=len(records),seconds=float(document[0].get('time','0')),
        additional_problem_entries=sum(max(0,len(r['problems'])-1) for r in records),cases=records)

def normalize(value):
    value=re.sub(r'[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}','UUID',value)
    value=re.sub(r'0x[0-9a-f]+','0xADDR',value)
    value=re.sub(r'/tmp/pytest-of-[^/\s]+/pytest-\d+','/tmp/PYTEST',value)
    return value

def primary(record):
    return next((p for p in record['problems'] if p['kind'] in {'failure','error'}),record['problems'][0] if record['problems'] else dict(message='',text=''))

def frames(text):
    return list(dict.fromkeys(re.findall(r'(?m)^((?:apps|tests|scripts|supabase)/[^:\n ]+):\d+',text)))

def analyze():
    hist=json.loads(HIST.read_text())
    old_path=Path('/tmp/memoir-review4-full-complete.xml')
    assert hashlib.sha256(old_path.read_bytes()).hexdigest()==hist['raw_evidence_sha256'][old_path.name]
    before=read(old_path);after=read('/tmp/memoir-cloud-current-full.xml')
    assert before['counts']=={'passed':5438,'failed':574,'error':21,'skipped':249}
    old=collections.defaultdict(list);new=collections.defaultdict(list)
    for r in before['cases']:old[r['nodeid']].append(r)
    for r in after['cases']:new[r['nodeid']].append(r)
    transitions=collections.Counter();changed=[]
    for node in sorted(old.keys()&new.keys()):
        a=dict(collections.Counter(r['outcome'] for r in old[node]));b=dict(collections.Counter(r['outcome'] for r in new[node]))
        key=' + '.join(f'{n} {s}' for s,n in sorted(a.items()))+' -> '+' + '.join(f'{n} {s}' for s,n in sorted(b.items()))
        transitions[key]+=1
        if a!=b:changed.append(dict(nodeid=node,historical=a,current=b))
    newly_failing=[dict(nodeid=n,historical=[r['outcome'] for r in old.get(n,[])],current=[r for r in new[n] if r['outcome'] in {'failed','error'}])
        for n in sorted(new) if any(r['outcome'] in {'failed','error'} for r in new[n]) and not any(r['outcome'] in {'failed','error'} for r in old.get(n,[]))]
    improved=[dict(nodeid=n,current=[r['outcome'] for r in new.get(n,[])]) for n in sorted(old)
        if any(r['outcome'] in {'failed','error'} for r in old[n]) and n in new and all(r['outcome']=='passed' for r in new[n])]
    previous={r['nodeid']:r for r in hist['remaining_failures_and_errors']}
    changed_files=set(subprocess.check_output(['git','diff','--name-only',BASE,HEAD],cwd=ROOT,text=True).splitlines())
    remaining=[];needs_review=[]
    for record in after['cases']:
        if record['outcome'] not in {'failed','error'}:continue
        node=record['nodeid'];problem=primary(record);former=previous.get(node)
        former_raw=old.get(node,[]);old_problem=primary(former_raw[0]) if former_raw else None
        current_frames=frames(problem['text']);same_test_source=node.split('::')[0] not in changed_files
        exact=old_problem is not None and normalize(problem['message'])==normalize(old_problem['message'])
        same_first_line=old_problem is not None and normalize(problem['message'].splitlines()[0] if problem['message'] else '')==normalize(old_problem['message'].splitlines()[0] if old_problem['message'] else '')
        same_repository_files=old_problem is not None and set(current_frames)==set(frames(old_problem['text']))
        item=dict(**record,current_repository_frames=current_frames,historical_classification=former,
            trace_comparison=dict(normalized_message_equal=exact,normalized_first_line_equal=same_first_line,
                repository_frame_files_equal=same_repository_files,failing_test_source_unchanged_since_b1=same_test_source),
            category='needs_current_review')
        if former and (exact or (same_first_line and same_repository_files and same_test_source)):
            item.update(category=former['category'],classification_evidence_id=former['classification_evidence_id'],
                classification_provenance='Current failure observed at the same normalized message/trace files, with historical evidence retained. Failing assertion stays failed; this comparison is not proof of acceptable behavior or a waiver.')
        elif former and former['category']=='aggregate_case_time_budget' and 'Timeout' in problem['message']:
            item.update(category='aggregate_case_time_budget',classification_evidence_id=former['classification_evidence_id'],
                classification_provenance='Current aggregate exhausted its 60-second per-case budget. Same-source separately budgeted diagnostics remain separate; the aggregate case remains failed.')
        else:needs_review.append(item)
        remaining.append(item)
    comparison=dict(historical_revision=BASE,historical_ledger=HIST.name,historical_counts=before['counts'],
        historical_records=before['collected_records'],historical_raw_xml_sha256=hashlib.sha256(old_path.read_bytes()).hexdigest(),
        current_execution_head=HEAD,current_source_test_revision=SOURCE,current_counts=after['counts'],current_records=after['collected_records'],
        common_unique_case_identities=len(old.keys()&new.keys()),historical_unique_case_identities=len(old),current_unique_case_identities=len(new),
        transitions=dict(transitions),changed_outcomes=changed,newly_failing=newly_failing,improved=improved,
        added=[dict(nodeid=n,outcomes=[r['outcome'] for r in new[n]]) for n in sorted(new.keys()-old.keys())],
        removed=[dict(nodeid=n,historical_outcomes=[r['outcome'] for r in old[n]]) for n in sorted(old.keys()-new.keys())],
        limit='Per-case identities and current trace/source checks preserve provenance. Historical runs remain historical. Matching IDs or classification does not make any current unmet assertion pass.')
    Path('/tmp/memoir-cloud-current-comparison.json').write_text(json.dumps(comparison,indent=2)+'\n')
    Path('/tmp/memoir-cloud-current-records.json').write_text(json.dumps(after,indent=2)+'\n')
    Path('/tmp/memoir-cloud-current-remaining.json').write_text(json.dumps(remaining,indent=2)+'\n')
    Path('/tmp/memoir-cloud-current-needs-review.json').write_text(json.dumps(needs_review,indent=2)+'\n')
    print(json.dumps(dict(counts=after['counts'],records=after['collected_records'],additional_problem_entries=after['additional_problem_entries'],
        newly_failing=[r['nodeid'] for r in newly_failing],improved=improved,added=len(comparison['added']),removed=len(comparison['removed']),needs_review=len(needs_review)),indent=2))

if __name__=='__main__':analyze()
