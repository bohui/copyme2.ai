from pathlib import Path
import collections,datetime,hashlib,json,re,runpy,subprocess

ROOT=Path('/workspace/memoir-baseline'); E=ROOT/'docs/test-evidence'
HEAD='9a89c4961b2448d8243c39fccdf1a66bc0b00edb'; P='/tmp/memoir-pr69-final'
BASE='memoir-baseline-repair-20261015'
f=runpy.run_path('/tmp/analyze_memoir_cloud_current.py');read=f['read'];primary=f['primary']
def load(p):return json.loads(Path(p).read_text())
def small(p):
    d=read(p)
    for r in d['cases']:
        r['problems']=[dict(kind=x['kind'],message_preview=x['message'][:600]) for x in r['problems']]
    return d
def node(p):
    s=Path(p).read_text();out={}
    for k in ['tests','suites','pass','fail','skipped','cancelled','todo','duration_ms']:
        v=re.findall(r'^ℹ '+k+r' ([0-9.]+)$',s,re.M)
        if v:out[k]=float(v[-1]) if '.' in v[-1] else int(v[-1])
    return out
def counts(d):return ', '.join(f'{d.get(k,0):,} {k}' for k in ['passed','failed','error','skipped'])

def build():
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==HEAD
    analysis=load(P+'-analysis.json');start=load(P+'-start.json');finish=load(P+'-finish.json')
    assert all(r['category']!='needs_current_review' and r['classification_evidence_id'] in analysis['classification_evidence'] for r in analysis['remaining_failures_and_errors'])
    helper_checks=[]
    for path,digest in start['frozen_helpers'].items():
        assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest
        helper_checks.append(dict(path=path,sha256=digest,matches_pre_execution_snapshot=True))
    receipts={p.stem:load(p) for p in Path(P+'-receipts').glob('*.json')}
    assert all(r['status']=='completed' and r['base_head']==HEAD and r['native_allocation_cleanup']['verified'] for r in receipts.values())
    browser=small(P+'-browser.xml');source=[r for r in browser['cases'] if 'tests/test_stage_' in r['nodeid']]
    assert len(source)==14 and all(r['outcome']=='passed' for r in source)
    mutant=small('/tmp/memoir-pr69-repair-resume-mutant-v2.xml')
    assert mutant['counts']=={'failed':2}
    for r in mutant['cases']:assert '--readiness:10%' in primary(r)['message_preview']
    # The complete historical checkpoint is immutable and available separately.
    history=load(E/'memoir-baseline-main-integration-20261015.json')
    historical_files={}
    for suffix in ['json','md','tar.gz']:
        path=E/f'memoir-baseline-main-integration-20261015.{suffix}'
        expected=subprocess.check_output(['git','show','affb313a6668c930189271be660785402a8b87fe:'+str(path.relative_to(ROOT))],cwd=ROOT)
        assert path.read_bytes()==expected;historical_files[str(path.relative_to(ROOT))]=hashlib.sha256(expected).hexdigest()
    baseline=load(E/'memoir-baseline-cloud-aggregate-20261015.json')
    old_raw=load(E/'memoir-baseline-cloud-raw-artifacts-20261015.json')
    assert all(hashlib.sha256(Path(r['original_path']).read_bytes()).hexdigest()==r['sha256'] for r in old_raw['artifacts'])
    all_cases=read(P+'-full.xml')['cases'];target={}
    prefixes={'runtime':'tests/test_lifetime_memory_runtime.py::','read_fences':'tests/test_lifetime_memory_reads.py::',
      'transport':'tests/test_postgres_fixture_transport.py::','original_text_route':'tests/test_agent_routes.py::test_agent_turn_forwards_original_text_separately_from_prompt',
      'phase_read_side_effects':'tests/test_conversation_phase_postgres.py::test_legacy_read_only_initializes_phase_without_admission_or_generation',
      'stage_nonretryable_conflicts':'tests/test_stage_application_conflicts.py::','global_application_conflicts':'tests/test_postgrest_application_conflicts.py::'}
    for name,prefix in prefixes.items():
        rows=[r for r in all_cases if r['nodeid'].startswith(prefix)];assert rows
        target[name]=dict(counts=dict(collections.Counter(r['outcome'] for r in rows)),record_indexes=[r['record_index'] for r in rows])
    del all_cases
    logs=Path(P+'-receipts/full-python.log').read_text()
    warnings=logs.split(' warnings summary ',1)[1].split('-- Docs:',1)[0] if ' warnings summary ' in logs else ''
    archive=runpy.run_path('/tmp/package_memoir_pr69_repair.py')['package']()
    report=dict(schema_version=1,repository='bohui/copyme2.ai',pull_request=69,date='2026-10-15',tested_revision=HEAD,tested_tree=start['tree'],acceptance_complete=False,
      source_heads=dict(main=start['current_main'],prior_executable=start['prior_execution_head'],preserved_checkpoint=start['evidence_checkpoint'],sql_repair=start['sql_repair_commit'],browser_fixture_repair=HEAD),
      start=start,finish=finish,source_preservation=load(P+'-source-proof.json'),environment=load(P+'-environment.json'),
      full_python=analysis,full_python_wall_seconds=receipts['full-python']['duration_seconds'],warnings=warnings,original_and_repair_target_scopes=target,
      comparison_to_prior_integrated_head=load(P+'-vs-prior.json'),
      new_process_observation_probe=small(P+'-process-observation-probe.xml'),
      repair_native=small(P+'-repair-native.xml'),upstream_affected=small(P+'-upstream-affected.xml'),capacity=small(P+'-capacity.xml'),
      javascript=node(P+'-receipts/javascript.log'),lint_exit=receipts['javascript-lint']['exit_code'],
      browser_selection=browser,source_frontend_browser_counts=dict(collections.Counter(r['outcome'] for r in source)),browser_network=load(P+'-browser-network.json'),browser_phases=load(P+'-browser-phases.json'),
      mobile=dict(node=node(P+'-receipts/mobile.log'),ui_jest=66,integration_jest=21,types_lint_openapi_native_config='passed; no native device/binary test'),
      web_build_exit=receipts['web-build']['exit_code'],mobile_export_exit=receipts['mobile-export']['exit_code'],acceptance=small(P+'-acceptance.xml'),localization=dict(messages=647,locales=2,exit_code=receipts['localization']['exit_code']),routes=dict(required=63,application=125,exit_code=receipts['routes']['exit_code']),
      tdd=dict(sql_red=small('/tmp/memoir-pr69-repair-stage-sql-red.xml'),sql_green=small('/tmp/memoir-pr69-repair-stage-sql-green.xml'),clock_order_probe=load('/tmp/memoir-pr69-repair-clock-order-probe.json'),resume_mutant=mutant,browser_green=small('/tmp/memoir-pr69-repair-browser-green-browser.xml'),
        precommit_source_limit='The uncommitted SQL red test version preceded the added upgrade case and Path import and was not separately snapshotted. Final test bytes are not claimed as the exact red-file bytes; raw red RPC errors and the unchanged committed audit are retained. No prior source file is reconstructed.',scope='SQL red was the native source/event 40001 and global audit failures. Mutant removes only the resume restart in a temporary source copy; repository production client is unchanged. All browser color/word/reload/project/no-new-turn assertions remain; the same 60-second bound now uses real time.'),
      resume_classification=dict(confirmed_fixture_defect='Late fake-clock installation after boot had scheduled native timers violates Playwright clock ordering; virtual request deadlines were mixed with real Auth/HTTP.',original_application_interleaving='Not captured. Earlier intermittent failures remain preserved. No new production polling defect or change is claimed.',repair='Use actual browser timers and a real 60-second30%-before-reload assertion. Mutation test still rejects missing restart in both languages.',references=['https://playwright.dev/python/docs/clock','https://playwright.dev/python/docs/api/class-clock#clock-fast-forward']),
      excluded_diagnostics=[dict(name='browser-observed-red',outcome='ImportError before pytest: Clock is not exported from playwright.sync_api; corrected in separate v2 helper.'),dict(name='browser-observed-red-v2',counts=small('/tmp/memoir-pr69-repair-browser-red-v2-browser.xml')['counts'],outcome='Confounded: timer wrappers introduced six reload bootstrap failures. Both resume snapshots were30% before reload. This does not reproduce or explain the original 10% application failure; not passing acceptance evidence.'),dict(name='resume-mutant',outcome='Before pytest: wrong standalone-server subpath in temporary app copy; corrected using detected server path in separate v2 helper.')],
      container_gate=dict(repeated=False,source_unchanged=True,prior_dns_failure='Docker daemon could not resolve auth.docker.io before image download.',node26_container_runtime='unrun',parent_reported_node26_standalone='Passed at59086eb; not an own final-head Node26 runtime check.'),
      runner_receipts=receipts,helper_hash_checks=helper_checks,helper_provenance='Primary final helpers hashed before execution and rechecked afterwards; per-check snapshots retain actual arguments. Precommit TDD/diagnostic attempts retain exact separate helper versions/receipts without claiming independent prior hash snapshots for every helper.',
      historical_helper_qualification=start['historical_helper_qualification'],historical_42_original_hashes_reverified=True,historical_checkpoint_hashes=historical_files,
      prior_parent_supplied_review=history['subsequent_parent_reported_current_head_review'],historical_parent_platform_evidence=baseline['parent_verified_external_results'],
      parent_supplied_final_head_review=load(P+'-independent-review.json'),
      unresolved_policy_decisions=baseline['policy_decisions_still_open'],zombie_observation=load(P+'-zombie-observation.json'),
      resource_scope='Registered task roots/sessions and owned frontend/backend teardown verified. Exact ordinary-runner group observation retains PID1 zombie as unreaped; no global PID-absence claim. Temporary source-copy files are evidence inputs, not deployed services. No unrelated cleanup.',
      remaining_gates=['All current full failures/errors remain unmet; current skips and four browser fixture failures are indexed and not waived.','New process-observation aggregate failure returned incomplete instead of observation. Isolated unchanged probe passed in 1.50s; cause and aggregate child cleanup details remain unestablished, with temporary receipt unavailable. No baseline/environment attribution is assumed.','Pending-proposal authority, outside-composer photo epochs, older workspace/round-five draft and canonical benchmark/dataset/model decisions remain open.','Earlier intermittent resume application interleaving remains unproven; the known invalid test-clock setup is repaired and real-clock/mutation coverage retained. Independent exact-head re-review supports these scoped fixes but does not waive remaining gates.','Node26 container runtime, live providers/evaluation, real Auth, native mobile devices and new Mac execution remain unrun. CI is empty per parent report; full aggregate was not independently rerun. Historical platform reports are narrow and not new results.'],raw_archive=archive,
      data_and_actions='Disposable synthetic databases/services only. No real user data, provider calls, production migration, merge to main, deployment, credential export, access/security change or external-agent contact.',
      representation='Every current failure/error and skip indexed by exact case-identity SHA and zero-based raw JUnit record; long synthetic image/body IDs abbreviated only in readable JSON. Complete current JUnit, every problem entry/attribute/duration, all check/TDD/diagnostic logs, receipts and helper versions are preserved losslessly. Earlier full runs remain in the immutable affb313 archive.')
    (E/(BASE+'.json')).write_text(json.dumps(report,indent=2)+'\n')
    categories='\n'.join(f'| `{k}` | {v} |' for k,v in sorted(analysis['classification_categories'].items()))
    skip_rows='\n'.join(f'| {k.replace(chr(124),chr(92)+chr(124))} | {v} |' for k,v in analysis['skip_reason_counts'].items())
    md=f'''# PR69 scoped compatibility repair

Tested executable head: `{HEAD}`; main `{start['current_main']}`.
SQL repair `{start['sql_repair_commit']}`; final browser-fixture repair `{HEAD}`.
The following commit adds evidence only. Human ready-for-review status is preserved;
the PR remains unmerged. **Acceptance is incomplete.**

## Repairs and TDD

Upstream migration003 recreated the stage writer with three application-conflict
`40001` branches after the earlier nonretryable conversion. New forward migration006
restores only those error codes to `PT409`; upstream attribution DDL, predicates,
messages, function identity, owner, grants and data are preserved. Native red was
**3 failed / 5 passed** (source/event wrong-version RPCs and global audit). Green
was **38 passed**, including stale evidence, all-table no-mutation snapshots,
authority preservation, upgrade replay and stage/provenance/lifecycle regressions.
PostgREST documents `PTxyz` custom status codes; actual HTTP retry behavior was not
measured here. [PostgREST error reference](https://docs.postgrest.org/en/stable/references/errors.html#raise-errors-with-http-status-codes).

The resume fixture installed a fake clock after boot scheduled native timers,
then jumped virtual request deadlines while Auth/HTTP still ran in real time.
Playwright documents that installation ordering as unsupported. A controlled
probe observed **10% with late install versus 30% with install before boot** after
the same 60-second virtual jump (under 0.1s wall). The corrected scenario uses actual
browser timers and the same 60-second bound, asserting 30% **before reload**, then
retaining reload, amber-color, 300-word, project and no-new-turn assertions.
[Playwright clock ordering](https://playwright.dev/python/docs/clock).

The production client is unchanged. Removing only its saved-project recovery
restart in a temporary source copy caused **both real-clock cases to fail at 10%**.
With production source, all 14 source-browser cases passed. The exact original
intermittent application timer interleaving was not captured; this repairs a
demonstrated fixture defect and does not claim a newly discovered polling defect.
Earlier failures remain in the checkpoint. Subsequent parent-supplied independent
review of exact `9a89c49`/`400f352` supports both scoped fixes: 41 native checks,
281 functions compared with only three intended substitutions and no data or
authority change; old mixed-clock 45/5 reproduced, revised real-time 46/4 with 14
source cases passed, and both missing-restart mutants failed. It reported 64 JS
subset passes, exact edition retirement passed, photo-policy/pending-proposal
failures retained, 15 PostgreSQL allocations/roots cleaned and three frontend
servers reaped. These scopes may overlap and are not summed with author results.
The original application interleaving remains unestablished. Reviewer raw artifacts
are not available here; full aggregate was not independently rerun and CI/container/
live/real-Auth/Mac gates remain open. Human ready status does not waive those gates.

## Fixed-head results

| Check | Result |
| --- | --- |
| Complete Python, two workers, 60s case bound | **{counts(analysis['current_counts'])}**; {analysis['current_records']:,} XML records; {receipts['full-python']['duration_seconds']:.2f}s wall |
| Native SQL repair/stage selection | **{counts(report['repair_native']['counts'])}** |
| Upstream acknowledgement/continuity/startup selection | **{counts(report['upstream_affected']['counts'])}** |
| Seven large-capacity cases, 600s bound | **{counts(report['capacity']['counts'])}** |
| JavaScript/composer/historical-news | **{report['javascript']['pass']} passed**, no failures/skips |
| Expanded browser/fixture selection | **{counts(browser['counts'])}**; all 14 source cases passed |
| Mobile | **87 Node + 66 UI Jest + 21 integration Jest passed**, types/lint/OpenAPI/native-config passed |
| Host web build and offline mobile JavaScript export | Passed; Node24, no native device execution |
| Acceptance catalogue | **55 passed**, MemoryStore scope |
| Localization/routes | **647 messages**, 63 required routes present among 125 |
| Syntax/whitespace | **{report['environment']['python_syntax']['files']} Python files parsed**, whitespace passed |
| Node26 container runtime | Unrun: prior Docker registry DNS gate remains blocked; unchanged Containerfile |

The original runtime/read/transport/route/read-side-effect scopes and both SQL
conflict modules are indexed separately in the manifest. No assertion is waived
by a passing focused/capacity run. Every remaining current failure/error and skip
is indexed with trace/classification evidence and its full raw XML record.

| Current observed classification | Records |
| --- | ---: |
{categories}

| Exact aggregate skip reason | Records |
| --- | ---: |
{skip_rows}

Four canonical identity/recovery fixture failures remain in the expanded browser
selection. All aggregate skips remain recorded; the 14 separate source-browser
passes do not make other opt-in/CLI/plugin/live gates pass. Pending-proposal and
photo-policy decisions, older workspace/draft policy and canonical dataset/model
approvals remain open. Capacity600s passes establish only that separate bounded
correctness run; aggregate timeouts remain failures and no latency SLA is claimed.

The final aggregate also newly failed
`test_completed_process_is_reaped_before_receipt_return`: the unchanged process
fixture returned `incomplete` instead of `observation`. Its unchanged isolated
probe passed in 1.50s with the original 2s execution/.4s cleanup/.1s stop-grace
budgets. The original child temporary receipt is unavailable after pytest
retention; exact cause and that child's aggregate cleanup details are unestablished.
This remains a newly observed unresolved failure, with no assumption that it is
baseline or environmental. Compared with `59086eb`, the SQL audit improves, four
new SQL cases pass, this process case fails and one additional capacity case
times out. All outcomes remain in both raw runs and the per-case comparison.

## Retained attempts, provenance and limits

The earlier two complete integration runs and review findings are preserved
unchanged at [checkpoint affb313](https://github.com/bohui/copyme2.ai/blob/affb313a6668c930189271be660785402a8b87fe/docs/test-evidence/memoir-baseline-main-integration-20261015.md).
No older failure was assumed preexisting solely by matching status. The original
unverified 647-failure/275-error aggregate is not baseline proof. The manifest
compares every case against b4 and 59086eb, recording additions and status changes.

Diagnostic attempts remain explicit: the first observer had an import error
before tests; v2 was confounded by its timer wrappers and introduced six reload
bootstrap failures (40 passed/10 failed, with both resume snapshots 30% before
reload). This is not reproduction of the original 10% symptom. The first temporary
mutant server used the wrong standalone subpath and failed before tests; v2's
two functional failures are the valid mutation result. None is silently removed
or relabeled as passing acceptance.

Primary final helper hashes were captured before execution and verified afterwards;
per-check metadata retains exact actual arguments. Precommit probes/TDD retain
their retained source versions and receipts without claiming prior hash snapshots
for every helper. The uncommitted SQL red test file was not separately snapshotted
before the later upgrade test and Path import were added; final test bytes are
not presented as its exact earlier version. Raw native rejections and the unchanged
committed audit remain available. No earlier red source is reconstructed.
The historical qualification remains: **c747/e8 final helper
settings differ from eight earlier receipt commands; earlier versions were not
supplied.** Their receipts remain authoritative. All 42 historical originals still
match their audited hashes; no missing original or helper version was reconstructed.

Registered native roots/sessions and browser frontend/backend teardown are
verified within their task scope. Ordinary-runner zombies are reported as PID1,
not running and not reaped. No global PID-absence claim or unrelated cleanup is
made. Earlier parent-reported Mac/Node26 results remain historical and narrower;
there is no new Mac, native-mobile, live-provider or container-runtime acceptance.

[Manifest and all current unmet records]({BASE}.json) · [Lossless raw archive]({BASE}.tar.gz).
Archive: **{archive['regular_files']} regular files**, {archive['bytes']:,} bytes,
SHA256 `{archive['sha256']}`. Every member was read back and matched to its original
bytes/hash. Full JUnit identities, problem entries, attributes and durations,
every raw check/TDD/diagnostic log/receipt and all retained helper versions are available without
redaction; long synthetic parameter IDs are abbreviated only in readable JSON.

Only disposable synthetic data/services were used. No real memoir data, provider
calls, production migration, merge to main, deployment, credential export,
access/security change or external-agent contact occurred.
'''
    (E/(BASE+'.md')).write_text(md)
    print(json.dumps(dict(head=HEAD,counts=analysis['current_counts'],archive_files=archive['regular_files'],archive_sha256=archive['sha256']),indent=2))

if __name__=='__main__':build()
