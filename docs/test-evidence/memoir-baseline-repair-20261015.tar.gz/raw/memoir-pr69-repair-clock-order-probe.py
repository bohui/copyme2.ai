import json,time
from pathlib import Path
from playwright.sync_api import sync_playwright

observations=[]
with sync_playwright() as pw:
    browser=pw.chromium.launch(executable_path='/usr/bin/chromium')
    try:
        for order in ['late_install','before_boot']:
            page=browser.new_page();start=time.monotonic()
            if order=='before_boot':page.clock.install()
            page.set_content('<script>window.syntheticRing=10;setTimeout(()=>window.syntheticRing=30,2000)</script>')
            if order=='late_install':page.clock.install()
            page.clock.fast_forward(60000)
            observations.append(dict(order=order,after_60000_virtual_ms=page.evaluate('window.syntheticRing'),wall_seconds=time.monotonic()-start))
            page.close()
    finally:browser.close()
Path('/tmp/memoir-pr69-repair-clock-order-probe.json').write_text(json.dumps(dict(observations=observations,scope='Isolated native-timer control diagnostic only; no application result is replaced by this probe.'),indent=2)+'\n')
assert observations[1]['after_60000_virtual_ms']==30
