from pathlib import Path
import collections,hashlib,json,runpy
f=runpy.run_path('/tmp/analyze_memoir_cloud_current.py')

def group(cases):
    out=collections.defaultdict(list)
    for r in cases:out[r['nodeid']].append(r)
    return out
def identity(node):return dict(nodeid=node if len(node)<=240 else None,nodeid_sha256=hashlib.sha256(node.encode()).hexdigest())

if __name__=='__main__':
    a=f['read']('/tmp/memoir-pr69-current-main-full.xml');b=f['read']('/tmp/memoir-pr69-final-full.xml')
    old=group(a['cases']);new=group(b['cases']);transitions=collections.Counter();changed=[]
    for node in old.keys()&new.keys():
        before=dict(collections.Counter(r['outcome'] for r in old[node]));after=dict(collections.Counter(r['outcome'] for r in new[node]))
        key=json.dumps(before,sort_keys=True)+' -> '+json.dumps(after,sort_keys=True);transitions[key]+=1
        if before!=after:changed.append(dict(**identity(node),before=before,after=after))
    result=dict(previous_head='59086ebed443d2b5e3d2fe51a53f462911a2a0c9',current_head='9a89c4961b2448d8243c39fccdf1a66bc0b00edb',previous_counts=a['counts'],current_counts=b['counts'],transitions=dict(transitions),changed_outcomes=sorted(changed,key=lambda r:r['nodeid_sha256']),
        added=[dict(**identity(n),outcomes=[r['outcome'] for r in new[n]]) for n in sorted(new.keys()-old.keys())],removed=[dict(**identity(n),outcomes=[r['outcome'] for r in old[n]]) for n in sorted(old.keys()-new.keys())],
        limit='Matching outcomes do not establish acceptable behavior. Every current unmet assertion stays failed and every raw trace remains available.')
    Path('/tmp/memoir-pr69-final-vs-prior.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in {'transitions','upstream_rename','limit'}},indent=2))
