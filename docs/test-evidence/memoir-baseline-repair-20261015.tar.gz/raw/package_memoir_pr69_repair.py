from pathlib import Path
import gzip, hashlib, io, json, re, tarfile

ROOT = Path('/workspace/memoir-baseline')
DEST = ROOT / 'docs/test-evidence/memoir-baseline-repair-20261015.tar.gz'

def package():
    files = set()
    for path in [*Path('/tmp').glob('memoir-pr69-final*'), *Path('/tmp').glob('memoir-pr69-repair*')]:
        if path.name == 'memoir-pr69-repair-final-report-build.log':
            continue  # This packaging command's own live stdout is not a test artifact.
        if path.is_file(): files.add(path)
        elif path.is_dir(): files.update(p for p in path.rglob('*') if p.is_file() and not p.is_symlink())
    files.update(Path('/tmp').glob('run_memoir_pr69_final*.py'))
    files.update(Path('/tmp').glob('run_memoir_pr69_repair*.py'))
    files.update([Path('/tmp/analyze_memoir_cloud_current.py'),Path('/tmp/analyze_memoir_pr69_final.py'),
        Path('/tmp/build_memoir_pr69_repair_report.py'),Path('/tmp/compare_memoir_pr69_final.py'),Path(__file__),
        Path('/tmp/memoir-pr69-resume-mutant-source/apps/web/client/memoir/client.js')])
    artifacts = []
    secret_pattern = re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|\bgh[pousr]_[A-Za-z0-9]{20,}|\bsk-(?:proj-)?[A-Za-z0-9_-]{24,}|\bAKIA[0-9A-Z]{16}')
    findings = []
    content = {}
    for path in sorted(files):
        assert path.is_file() and not path.is_symlink()
        value = path.read_bytes()
        if secret_pattern.search(value):
            findings.append(str(path))
        member = 'raw/' + str(path.relative_to('/tmp'))
        artifacts.append(dict(original_path=str(path), archive_member=member, bytes=len(value),
                              sha256=hashlib.sha256(value).hexdigest(), redacted=False))
        content[member] = value
    assert not findings, findings
    with DEST.open('wb') as output:
        with gzip.GzipFile(fileobj=output, mode='wb', mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w') as archive:
                for member, value in content.items():
                    info = tarfile.TarInfo(member); info.size=len(value); info.mode=0o644
                    archive.addfile(info, io.BytesIO(value))
    matched = 0
    with tarfile.open(DEST, 'r:gz') as archive:
        assert len(archive.getmembers()) == len(artifacts)
        for entry in artifacts:
            member = archive.getmember(entry['archive_member'])
            assert member.isfile() and not member.name.startswith('/') and '..' not in Path(member.name).parts
            value = archive.extractfile(member).read()
            assert value == Path(entry['original_path']).read_bytes()
            assert hashlib.sha256(value).hexdigest() == entry['sha256']
            matched += 1
    return dict(repository_path=str(DEST.relative_to(ROOT)), bytes=DEST.stat().st_size,
                sha256=hashlib.sha256(DEST.read_bytes()).hexdigest(), regular_files=len(artifacts),
                exact_byte_readback_matches=matched, artifacts=artifacts,
                sensitivity_review=dict(scope='Synthetic test logs, receipts, fixture-only source, helper source and local environment/version metadata. No environment credential values exported.',
                                        private_key_or_common_provider_token_pattern_matches=findings,
                                        redactions=0, limit='Pattern scan is a limited check, not a universal secret detector.'))

if __name__ == '__main__':
    result = package()
    Path('/tmp/memoir-pr69-repair-package-result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in {'artifacts','sensitivity_review'}},indent=2))
