import hashlib,json,os,subprocess,sys
from pathlib import Path

ROOT=Path('/workspace/memoir-baseline')
HEAD='9a89c4961b2448d8243c39fccdf1a66bc0b00edb'
PREFIX='/tmp/memoir-pr69-final'
name=sys.argv[1]
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==HEAD
baseline=json.loads((ROOT/'docs/test-evidence/memoir-baseline-review-four-20261015.json').read_text())
node_files=[*sorted(ROOT.glob('tests/js/*.test.mjs')),*sorted(ROOT.glob('tests/historical-news/*.test.mjs')),*sorted(ROOT.glob('skills/memoir-composer/tests/*.test.mjs'))]
lint_files=subprocess.check_output(['git','diff','--name-only','46caa5fc2c2c5af2d4f7280bea74cc75184c9cbc','HEAD','--','*.js','*.mjs','*.cjs'],cwd=ROOT,text=True).splitlines()
checks={
 'upstream-affected':(['python','-m','pytest','-q','tests/test_lifetime_memory_continuity.py','tests/test_lifetime_actual_engines.py','tests/test_lifetime_memory_engine.py','tests/test_container_startup.py','tests/test_web_container_config.py','docs/test-evidence/test_issue53_parallel_ack_prototype.py','--timeout=180','--tb=short',f'--junitxml={PREFIX}-upstream-affected.xml'],1200,ROOT),
 'repair-native':(['python','-m','pytest','-q','tests/test_stage_application_conflicts.py','tests/test_postgrest_application_conflicts.py','tests/test_stage_progress_regression.py','tests/test_stage_readiness_provenance.py','tests/test_stage_progress_rpc_lifecycle.py','--timeout=60','--tb=short',f'--junitxml={PREFIX}-repair-native.xml'],600,ROOT),
 'full-python':(['python','-m','pytest','-q','-n2','--dist=loadfile','--timeout=60','--timeout-method=signal','--tb=short',f'--junitxml={PREFIX}-full.xml'],5400,ROOT),
 'capacity':(['python','-m','pytest','-q',*[c['nodeid'] for c in baseline['capacity_reruns']['cases']],
    '--timeout=600','--timeout-method=signal','--tb=short',f'--junitxml={PREFIX}-capacity.xml'],5400,ROOT),
 'javascript':(['node','--test',*map(str,node_files)],1200,ROOT),
 'javascript-lint':([str(ROOT/'node_modules/.bin/eslint'),*lint_files],300,ROOT),
 'mobile':(['npm','run','check:mobile'],1800,ROOT),
 'mobile-export':(['npm','run','build:mobile'],1800,ROOT),
 'web-build':(['npm','run','build','--','--webpack'],1800,ROOT/'apps/web'),
 'browser-standalone':(['python','/tmp/run_memoir_pr69_final_browser.py'],1800,ROOT),
 'acceptance':(['python','-m','pytest','-q','tests/test_full_acceptance.py','--timeout=180','--tb=short',f'--junitxml={PREFIX}-acceptance.xml'],1200,ROOT),
 'localization':(['python','scripts/check_localization_catalog.py'],300,ROOT),
 'routes':(['python','scripts/audit_spec_routes.py','--spec','docs/Memory_Spark_Full_Specification_v1.0.md'],300,ROOT),
}
command,timeout,cwd=checks[name]
prefix=['env','PYTHONPATH=/tmp/memoir-test-tools:.',
 'LD_LIBRARY_PATH=/workspace/.tools/postgresql/usr/lib/x86_64-linux-gnu',
 'MEMOIR_TEST_TEMPORAL_CLI=/workspace/.tools/temporal/temporal','PYTHONHASHSEED=0',
 'EXPO_OFFLINE=1','EXPO_NO_TELEMETRY=1','NPM_CONFIG_UPDATE_NOTIFIER=false']
if cwd!=ROOT:
 command=['python','-c','import os,sys; os.chdir(sys.argv[1]); os.execvp(sys.argv[2],sys.argv[2:])',str(cwd),*command]
args=['python',str(ROOT/'scripts/run_isolated_check.py'),'--root',str(ROOT),
 '--output-dir',PREFIX+'-receipts','--name',name,'--timeout',str(timeout),'--',*prefix,*command]
helper=Path(__file__);digest=hashlib.sha256(helper.read_bytes()).hexdigest()
snapshot=dict(head=HEAD,name=name,helper_path=str(helper),helper_sha256=digest,actual_runner_args=args,
    provenance='Helper finalized before any integration check; exact bytes rechecked after execution. Old c747 helper snapshots remain separate and are not modified.')
Path(PREFIX+'-'+name+'-helper.json').write_text(json.dumps(snapshot,indent=2)+'\n')
code=subprocess.call(args,cwd=ROOT)
assert hashlib.sha256(helper.read_bytes()).hexdigest()==digest
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==HEAD
print(json.dumps(dict(name=name,exit_code=code,helper_unchanged=True)))
raise SystemExit(code)
