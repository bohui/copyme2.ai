"""Observation only: native wall time, virtual timer phase, readiness fetches/paint."""
from playwright.sync_api import Page, Clock

pages=[]
snapshots=[]
script=r"""(() => {
  const wall = Date.now.bind(Date);
  const log = [];
  window.__memoirClockTrace = log;
  const record = (kind, data={}) => log.push({kind,wall:wall(),virtual:Date.now(),...data});
  window.__memoirTraceTimers = phase => {
    const schedule = window.setTimeout.bind(window), cancel = window.clearTimeout.bind(window);
    record('timer_api', {phase});
    window.setTimeout = function(fn,delay,...args) {
      if (typeof fn !== 'function' || delay < 2000 || delay > 300000) return schedule(fn,delay,...args);
      let id;
      id=schedule(function(...values) {record('timer_fired',{phase,id,delay});return fn.apply(this,values);},delay,...args);
      record('timer_started',{phase,id,delay});return id;
    };
    window.clearTimeout = id => {record('timer_cleared',{phase,id});return cancel(id);};
  };
  window.__memoirTraceTimers('native_before_install');
  const fetch = window.fetch.bind(window);
  window.fetch = async (input,options={}) => {
    const path = new URL(typeof input==='string' ? input : input.url,location.href).pathname;
    if (!path.endsWith('/story/readiness')) return fetch(input,options);
    record('read_started');
    options.signal?.addEventListener('abort',()=>record('read_aborted'),{once:true});
    try {const response=await fetch(input,options);record('read_headers',{status:response.status});return response;}
    catch(error) {record('read_failed',{name:error.name});throw error;}
  };
  let previous;
  new MutationObserver(()=>{
    const style=document.querySelector('[data-life-stage-tab="childhood"] .life-stage-readiness')?.getAttribute('style');
    if(style && style!==previous) {previous=style;record('paint',{style});}
  }).observe(document,{subtree:true,childList:true,attributes:true,attributeFilter:['style']});
})();"""
goto=Page.goto
def observed_goto(page,*args,**kwargs):
    pages.append(page);page.add_init_script(script)
    return goto(page,*args,**kwargs)
Page.goto=observed_goto
install=Clock.install
def observed_install(clock,*args,**kwargs):
    result=install(clock,*args,**kwargs)
    for page in pages:
        if not page.is_closed() and page.clock._impl_obj is clock._impl_obj:
            page.evaluate("window.__memoirTraceTimers?.('virtual_after_install')")
    return result
Clock.install=observed_install
reload=Page.reload
def observed_reload(page,*args,**kwargs):
    snapshots.append(page.evaluate("({path:location.pathname,locale:document.documentElement.lang,style:document.querySelector('[data-life-stage-tab=\"childhood\"] .life-stage-readiness')?.getAttribute('style'),trace:window.__memoirClockTrace})"))
    return reload(page,*args,**kwargs)
Page.reload=observed_reload
