import hashlib,json,os,subprocess,tempfile,time,uuid
from pathlib import Path

root=Path('/workspace/memoir-baseline')
head='59086ebed443d2b5e3d2fe51a53f462911a2a0c9'
prefix='/tmp/memoir-pr69-current-main-container'
nonce=uuid.uuid4().hex
tag='memoir-pr69-local-check:'+nonce
label='memoir.pr69.check='+nonce
container=None; image=None
result=dict(execution_head=head,owned_tag=tag,ownership_label=label,
            scope='Local disposable Node 26 production-image build and network-disabled runtime smoke only; no production deployment or provider calls.')
config=tempfile.TemporaryDirectory(prefix='memoir-pr69-docker-config-')
env=dict(os.environ,DOCKER_CONFIG=config.name,DOCKER_BUILDKIT='1')
docker=['docker','--host','unix:///var/run/docker.sock']
def run(args,**kwargs):
    return subprocess.run(docker+args,env=env,check=True,text=True,**kwargs)
try:
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==head
    assert not list((root/'apps/web').glob('.env'))
    assert not [p for p in (root/'apps/web').glob('.env.*') if p.name!='.env.example']
    result['build_command']=docker+['build','--progress=plain','--label',label,'--tag',tag,
        '--build-arg','MEMORY_SPARK_API_ORIGIN=http://127.0.0.1:9','-f',str(root/'apps/web/Containerfile'),str(root/'apps/web')]
    subprocess.run(result['build_command'],env=env,check=True,timeout=1200)
    image=json.loads(run(['image','inspect',tag],capture_output=True).stdout)[0]
    assert image['Config']['Labels']['memoir.pr69.check']==nonce
    result['image_id']=image['Id']
    container=run(['run','--detach','--network','none','--label',label,
        '--env','HOSTNAME=127.0.0.1','--env','PORT=3000',tag],capture_output=True).stdout.strip()
    inspect=json.loads(run(['inspect',container],capture_output=True).stdout)[0]
    assert inspect['Config']['Labels']['memoir.pr69.check']==nonce
    assert inspect['HostConfig']['NetworkMode']=='none'
    result['container_id']=container
    deadline=time.monotonic()+40
    while True:
        logs=run(['logs',container],capture_output=True).stdout
        if 'Ready in' in logs:break
        assert time.monotonic()<deadline,'Owned frontend did not become ready'
        time.sleep(.1)
    result['node_version']=run(['exec',container,'node','--version'],capture_output=True).stdout.strip()
    probe="const r=await fetch('http://127.0.0.1:3000/memoir');const t=await r.text();if(r.status!==200||!t.includes('memoir'))throw Error('page smoke failed '+r.status);console.log(JSON.stringify({status:r.status,bytes:t.length}));"
    result['page']=json.loads(run(['exec',container,'node','--input-type=module','-e',probe],capture_output=True).stdout)
    result['passed']=True
finally:
    if container:
        inspect=json.loads(run(['inspect',container],capture_output=True).stdout)[0]
        assert inspect['Config']['Labels']['memoir.pr69.check']==nonce
        run(['rm','--force',container])
        gone=subprocess.run(docker+['inspect',container],env=env,capture_output=True,text=True)
        assert gone.returncode!=0
        result['owned_container_removed']=True
    if image:
        current=json.loads(run(['image','inspect',tag],capture_output=True).stdout)[0]
        assert current['Id']==image['Id'] and current['Config']['Labels']['memoir.pr69.check']==nonce
        run(['image','rm',tag])
        result['owned_image_tag_removed']=True
    config.cleanup()
    result['temporary_docker_config_removed']=True
    result['build_cache_limit']='Shared daemon build cache is retained; no global prune or unrelated image/container operation is performed.'
    Path(prefix+'-result.json').write_text(json.dumps(result,indent=2)+'\n')
