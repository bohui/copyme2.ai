from pathlib import Path
import collections, gzip, hashlib, json, re, runpy, subprocess

ROOT = Path('/workspace/memoir-baseline')
PREFIX = Path('/tmp/memoir-pr69-integration')
OLD = 'e8e7025d2338295d89cbd825a673c871e8baf37c'
HEAD = '09cd7ad973c7b1df1774c639401b4ef9895a9cb7'
functions = runpy.run_path('/tmp/analyze_memoir_cloud_current.py')
read, primary, normalize, frames = (functions[n] for n in ('read', 'primary', 'normalize', 'frames'))

def sha(value):
    return hashlib.sha256(value.encode()).hexdigest()

def compact(record):
    node = record['nodeid']
    return dict(record_index=record['record_index'], nodeid=node if len(node) <= 240 else None,
                nodeid_preview=node[:200], nodeid_sha256=sha(node), outcome=record['outcome'],
                seconds=record['seconds'])

def identity_map(records):
    result = collections.defaultdict(list)
    for record in records:
        result[record['nodeid']].append(record)
    return result

def analyze():
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == HEAD
    ledger = json.loads((ROOT / 'docs/test-evidence/memoir-baseline-cloud-aggregate-20261015.json').read_text())
    with gzip.open(ROOT / 'docs/test-evidence/memoir-baseline-cloud-aggregate-20261015.junit.xml.gz', 'rb') as stream:
        before = read(stream)
    after = read(str(PREFIX) + '-full.xml')
    old = identity_map(before['cases']); new = identity_map(after['cases'])
    previous = {r['nodeid_sha256'] if r.get('nodeid_sha256') else sha(r['nodeid']): r
                for r in ledger['remaining_failures_and_errors']}
    changed_files = set(subprocess.check_output(['git', 'diff', '--name-only', OLD, HEAD], cwd=ROOT, text=True).splitlines())
    remaining = []; review = []
    for record in after['cases']:
        if record['outcome'] not in {'failed', 'error'}:
            continue
        item = compact(record); problem = primary(record); prior = previous.get(item['nodeid_sha256'])
        candidates = sorted([r for r in old.get(record['nodeid'], []) if r['outcome'] in {'failed', 'error'}],
                            key=lambda r: r['outcome'] != record['outcome'])
        former = primary(candidates[0]) if candidates else None
        exact = former is not None and normalize(former['message']) == normalize(problem['message'])
        first = former is not None and normalize(former['message'].splitlines()[0]) == normalize(problem['message'].splitlines()[0])
        trace = former is not None and set(frames(former['text'])) == set(frames(problem['text']))
        item.update(primary_kind=problem['kind'], message_preview=problem['message'][:450],
                    current_repository_frames=frames(problem['text']),
                    test_source_unchanged_from_old_pr69=record['nodeid'].split('::')[0] not in changed_files,
                    trace_comparison=dict(normalized_message_equal=exact, normalized_first_line_equal=first,
                                          repository_frame_files_equal=trace),
                    category='needs_current_review')
        if prior and (exact or (first and trace and item['test_source_unchanged_from_old_pr69'])):
            item.update(category=prior['category'], classification_evidence_id=prior['classification_evidence_id'])
        elif prior and prior['category'] == 'aggregate_case_time_budget' and 'Timeout' in problem['message']:
            item.update(category='aggregate_case_time_budget', classification_evidence_id=prior['classification_evidence_id'])
        else:
            review.append(item)
        remaining.append(item)
    transitions = collections.Counter(); changes = []
    for node in sorted(old.keys() & new.keys()):
        a = dict(collections.Counter(r['outcome'] for r in old[node])); b = dict(collections.Counter(r['outcome'] for r in new[node]))
        key = ' + '.join(f'{n} {s}' for s,n in sorted(a.items())) + ' -> ' + ' + '.join(f'{n} {s}' for s,n in sorted(b.items()))
        transitions[key] += 1
        if a != b:
            changes.append(dict(nodeid=node if len(node)<=240 else None, nodeid_sha256=sha(node), historical=a, current=b))
    added = [compact(r) for n in sorted(new.keys()-old.keys()) for r in new[n]]
    removed = [compact(r) for n in sorted(old.keys()-new.keys()) for r in old[n]]
    new_bad = [compact(r) for n in sorted(new) for r in new[n] if r['outcome'] in {'failed','error'}
               and not any(x['outcome'] in {'failed','error'} for x in old.get(n, []))]
    skipped = []
    for record in after['cases']:
        if record['outcome'] == 'skipped':
            item = compact(record)
            item['reasons'] = [p['message'] for p in record['problems'] if p['kind']=='skipped']
            skipped.append(item)
    result = dict(execution_head=HEAD, old_pr69_head=OLD, prior_execution_head=ledger['tested_revision'],
                  prior_source_revision=ledger['source_test_revision'], current_counts=after['counts'],
                  current_records=after['collected_records'], seconds=after['seconds'],
                  additional_problem_entries=after['additional_problem_entries'], historical_counts=before['counts'],
                  transitions=dict(transitions), changed_outcomes=changes, added=added, removed=removed,
                  newly_failing=new_bad, remaining_failures_and_errors=remaining,
                  classification_categories=dict(collections.Counter(r['category'] for r in remaining)),
                  classification_evidence=ledger['classification_evidence'], skipped=skipped,
                  skip_reason_counts=dict(collections.Counter(reason for r in skipped for reason in r['reasons'])),
                  limit='Every current failure, error, and skip remains unmet. Classification follows current traces and retained historical evidence, and is not a waiver. Exact identities and all problem entries remain in the lossless raw JUnit archive.')
    Path(str(PREFIX)+'-analysis.json').write_text(json.dumps(result,indent=2)+'\n')
    Path(str(PREFIX)+'-needs-review.json').write_text(json.dumps(review,indent=2)+'\n')
    print(json.dumps(dict(counts=after['counts'], records=after['collected_records'],
                          categories=result['classification_categories'], added=len(added),removed=len(removed),
                          new_bad=new_bad, changes=changes, needs_review=len(review)),indent=2))

if __name__ == '__main__':
    analyze()
