from pathlib import Path
import collections,datetime,hashlib,json,re,runpy,subprocess

ROOT=Path('/workspace/memoir-baseline')
EVIDENCE=ROOT/'docs/test-evidence'
BASE='memoir-baseline-main-integration-20261015'
HEAD='59086ebed443d2b5e3d2fe51a53f462911a2a0c9'
PREFIX='/tmp/memoir-pr69-current-main'
functions=runpy.run_path('/tmp/analyze_memoir_cloud_current.py')
read,primary=(functions[n] for n in ('read','primary'))

def load(path):return json.loads(Path(path).read_text())
def node_summary(path):
    text=Path(path).read_text(); result={}
    for key in ['tests','suites','pass','fail','cancelled','skipped','todo','duration_ms']:
        values=re.findall(r'^ℹ '+key+r' ([0-9.]+)$',text,re.M)
        if values:result[key]=float(values[-1]) if '.' in values[-1] else int(values[-1])
    return result
def small_xml(path):
    raw=read(path)
    for item in raw['cases']:
        item['problems']=[dict(kind=p['kind'],message_preview=p['message'][:700]) for p in item['problems']]
    raw['raw_artifact']=str(path)
    return raw
def count_text(counts):return ', '.join(f'{counts.get(k,0):,} {k}' for k in ['passed','failed','error','skipped'])

def build():
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==HEAD
    current=load(PREFIX+'-analysis.json');first=load('/tmp/memoir-pr69-integration-analysis.json')
    assert all(r['category']!='needs_current_review' for r in current['remaining_failures_and_errors'])
    assert all(r['classification_evidence_id'] in current['classification_evidence'] for r in current['remaining_failures_and_errors'])
    starts=[load('/tmp/memoir-pr69-integration-start.json'),load(PREFIX+'-start.json')]
    helper_checks=[]
    for start in starts:
        for path,digest in start['frozen_helpers'].items():
            actual=hashlib.sha256(Path(path).read_bytes()).hexdigest();assert actual==digest
            helper_checks.append(dict(path=path,sha256=actual,matches_pre_execution_snapshot=True))
    receipts={p.stem:load(p) for p in Path(PREFIX+'-receipts').glob('*.json')}
    assert all(d['status']=='completed' for d in receipts.values())
    assert all(d['base_head']==HEAD for d in receipts.values())
    assert all(d['native_allocation_cleanup']['verified'] for d in receipts.values())
    log=Path(PREFIX+'-receipts/full-python.log').read_text()
    warning=log.split(' warnings summary ',1)[1].split('-- Docs:',1)[0] if ' warnings summary ' in log else ''
    browser=small_xml(PREFIX+'-browser.xml')
    first_browser=small_xml('/tmp/memoir-pr69-integration-browser.xml')
    full_records=read(PREFIX+'-full.xml')['cases']
    target_prefixes={
        'lifetime_runtime':'tests/test_lifetime_memory_runtime.py::',
        'lifetime_reads':'tests/test_lifetime_memory_reads.py::',
        'postgres_transport_contracts':'tests/test_postgres_fixture_transport.py::',
        'original_text_route_variants':'tests/test_agent_routes.py::test_agent_turn_forwards_original_text_separately_from_prompt',
        'legacy_phase_read_side_effect_invariants':'tests/test_conversation_phase_postgres.py::test_legacy_read_only_initializes_phase_without_admission_or_generation',
    }
    target_results={}
    for name,prefix in target_prefixes.items():
        records=[r for r in full_records if r['nodeid'].startswith(prefix)]
        assert records
        target_results[name]=dict(counts=dict(collections.Counter(r['outcome'] for r in records)),
            record_indexes=[r['record_index'] for r in records],archive_member='raw/memoir-pr69-current-main-full.xml')
    del full_records
    source_cases=[r for r in browser['cases'] if 'tests/test_stage_' in r['nodeid']]
    assert len(source_cases)==14
    assert all(r['outcome']=='passed' for r in source_cases)
    old_artifacts=load(EVIDENCE/'memoir-baseline-cloud-raw-artifacts-20261015.json')['artifacts']
    for entry in old_artifacts:assert hashlib.sha256(Path(entry['original_path']).read_bytes()).hexdigest()==entry['sha256']
    first_receipt=load('/tmp/memoir-pr69-integration-receipts/full-python.json')
    finish=load(PREFIX+'-finish.json')
    package=runpy.run_path('/tmp/package_memoir_pr69_integration.py')['package']()
    old_ledger=load(EVIDENCE/'memoir-baseline-cloud-aggregate-20261015.json')
    report=dict(schema_version=2,repository='bohui/copyme2.ai',pull_request=69,date='2026-10-15',
        tested_revision=HEAD,tested_tree=starts[1]['tree'],acceptance_complete=False,
        status='Conflict integration completed; ready-for-review is the human setting and does not waive open acceptance gates.',
        source_heads=dict(old_pr69=starts[0]['old_head'],pr68_reviewed=starts[0]['reviewed_pr68_head'],first_main=starts[0]['current_main'],first_merge=starts[0]['integration_head'],current_main=starts[1]['current_main'],current_merge=HEAD),
        merge_rounds=starts,source_preservation=[load('/tmp/memoir-pr69-integration-source-proof.json'),load(PREFIX+'-source-proof.json')],
        environment=load(PREFIX+'-environment.json'),finish=finish,
        originally_diagnosed_regression_scopes=target_results,
        full_python=current,full_python_wall_seconds=receipts['full-python']['duration_seconds'],warning_details=warning,
        current_capacity=small_xml(PREFIX+'-capacity.xml'),javascript=node_summary(PREFIX+'-receipts/javascript.log'),
        javascript_lint=dict(exit_code=receipts['javascript-lint']['exit_code'],scope='Every changed JS/MJS/CJS path since historical main 46caa5f, using the actual command in the receipt.'),
        upstream_affected=small_xml(PREFIX+'-upstream-affected.xml'),
        browser_selection=browser,source_frontend_browser_counts=dict(collections.Counter(r['outcome'] for r in source_cases)),
        browser_scope='14 actual source-frontend Chromium cases (10 use native SQL stage totals, four exercise current workspace/private-draft policy through synthetic services), plus 36 storage/auth/collection fixture cases. Auth/unrelated services are synthetic; no provider calls.',
        browser_network=load(PREFIX+'-browser-network.json'),browser_phases=load(PREFIX+'-browser-phases.json'),
        mobile=dict(node=node_summary(PREFIX+'-receipts/mobile.log'),ui_jest_passed=66,integration_jest_passed=21,exit_code=receipts['mobile']['exit_code'],scope='Type/lint/OpenAPI/native-config, Node/Jest and JavaScript export; no native binary/device execution.'),
        web_build=dict(exit_code=receipts['web-build']['exit_code'],node='24.19.0',scope='Host production webpack build; standalone source server also rebuilt for Chromium.'),
        mobile_export=dict(exit_code=receipts['mobile-export']['exit_code'],offline=True,telemetry_disabled=True),
        container_build=dict(receipt=receipts['container-build'],result=load(PREFIX+'-container-result.json'),cleanup=load(PREFIX+'-container-cleanup.json'),classification='environment_docker_registry_dns',node26_runtime_unrun=True),
        specification_acceptance=small_xml(PREFIX+'-acceptance.xml'),localization=dict(messages=647,locales=['en-AU','zh-CN'],exit_code=receipts['localization']['exit_code']),routes=dict(required=63,application=125,exit_code=receipts['routes']['exit_code']),
        first_integration=dict(head=starts[0]['integration_head'],full_counts=first['current_counts'],records=first['current_records'],wall_seconds=first_receipt['duration_seconds'],newly_failing=first['newly_failing'],classification_categories=first['classification_categories'],browser=first_browser,resume_probe=load('/tmp/memoir-pr69-integration-resume-diagnostic.json'),capacity=small_xml('/tmp/memoir-pr69-integration-capacity.xml'),complete_case_archive_member='raw/memoir-pr69-integration-full.xml',analysis_member='raw/memoir-pr69-integration-analysis.json'),
        comparison_to_first_integration=load(PREFIX+'-vs-first.json'),
        conflict_sql_diagnostic=load(PREFIX+'-conflict-function.json'),helper_hash_checks=helper_checks,
        helper_provenance='Primary helpers for each round were finalized and hashed before execution; per-check snapshots contain exact runner arguments and the check helper verifies itself and HEAD afterwards. Additional focused/probe helper bytes and wrapper commands are archived separately; they are not claimed to have independent pre-execution hash snapshots.',
        historical_helper_qualification=starts[0]['historical_helper_qualification'],historical_42_original_hashes_reverified=True,
        historical_baseline=dict(execution_head=old_ledger['tested_revision'],source_revision=old_ledger['source_test_revision'],counts=old_ledger['full_python']['counts'],raw_archive='memoir-baseline-cloud-raw-artifacts-20261015.tar.gz',qualification='Historical scopes and receipt/helper qualification remain explicit. The earlier unverified 647-failure/275-error aggregate is not used as baseline proof.'),
        parent_reported_independent_review=starts[1]['independent_review_parent_reported'],
        subsequent_parent_reported_current_head_review=load(PREFIX+'-independent-review.json'),
        previous_parent_reported_platform_evidence=old_ledger['parent_verified_external_results'],
        policy_decisions_still_open=old_ledger['policy_decisions_still_open'],
        resource_scope_limit='Runner receipts verify only registered task allocations/sessions. Frontend/backend and exact Docker ownership cleanup are separate. Ordinary runner zombie observations are retained and are not claimed reaped; no global PID-absence proof is made.',
        zombie_observations=[load('/tmp/memoir-pr69-integration-zombie-observation.json'),load(PREFIX+'-zombie-observation.json')],
        remaining_gates=[f"Every current full Python failure/error and all {len(current['skipped'])} aggregate skips remain unmet; classifications are not waivers.",
          'The upstream 40001/PT409 application-conflict regression remains failed. PR68 migration work was preserved under its ownership boundary.',
          'Four canonical identity/recovery fixture failures remain in the browser selection.',
          'The earlier English resume failure is retained with unresolved cause despite subsequent passing runs.',
          'Node26 production image compilation/runtime are blocked by Docker daemon registry DNS.',
          'Pending-proposal authority, outside-composer photo policy epochs, older workspace/private-draft policy, legacy benchmark/dataset and live canary/model decisions are not answered here.',
          'Subsequent independent review confirmed the SQLSTATE and English resume blockers at 59086eb. Scoped repairs and re-review are now authorized; no fix is claimed in this evidence checkpoint.',
          'No provider/live evaluation, production migration, deployment, PR merge, native Mac execution or native mobile device test was performed.'],
        raw_archive=package,
        exact_case_representation='All current failures/errors and skips are indexed by exact SHA256 and zero-based XML testcase index. Long synthetic byte/image parameter IDs are abbreviated only in readable JSON. Both complete aggregate JUnit files, every problem entry/attribute/duration, all raw check logs/receipts, helper versions, comparison analysis, precommit red/green evidence and focused probes are preserved losslessly in the raw tar archive.')
    (EVIDENCE/(BASE+'.json')).write_text(json.dumps(report,indent=2)+'\n')
    categories='\n'.join(f'| `{k}` | {v} |' for k,v in sorted(current['classification_categories'].items()))
    skips='\n'.join(f'| {reason.replace(chr(124),chr(92)+chr(124))} | {n} |' for reason,n in current['skip_reason_counts'].items())
    md=f'''# PR69 integration with PR68 and current main

Tested executable head: `{HEAD}`. Current main: `{starts[1]['current_main']}`.
The following evidence-only commit changes no executable/test bytes. PR69 remains
ready for review by human choice, open and unmerged. **Acceptance is incomplete.**

## Merge and ownership preservation

Old PR69 was `{starts[0]['old_head']}`. The first normal merge `{starts[0]['integration_head']}`
has parents old PR69 and PR68/main `{starts[0]['current_main']}` (reviewed PR68 head
`{starts[0]['reviewed_pr68_head']}`). Its only manual conflict was
`apps/web/client/memoir/client.js`; automatic overlaps were
`tests/js/stream-latency.test.mjs` and `tests/test_stage_readiness_browser.py`.
The complete PR68 readiness recovery body, navigation/turn/resume functions,
attribution migration and regressions were retained. PR69 draft eligibility,
unused-binding cleanup, transport assertions and canonical lifecycle work survive.

Main then advanced by 11 paths. The second normal merge `{HEAD}` has parents
`{starts[1]['previous_integration_head']}` and `{starts[1]['current_main']}`.
It had no manual conflict. Automatic overlaps were `apps/api/lifetime_memory_engine.py`,
`tests/test_container_startup.py` and `tests/test_lifetime_actual_engines.py`.
The main acknowledgement prompt and unique-quote validation are retained exactly,
including the Node26 container change and diagnostic-only prototype. PR69 trajectory,
Unix-socket/publication fixtures and spaced env-file assertions remain intact.
Only those 11 upstream paths differ from the first merge. No upstream policy,
authority guard or migration was rewritten to obtain a passing check.

Before the first merge, the PR68 readiness harness against old PR69 source was
**6 passed / 16 failed**. The combined candidate was **48 passed**, and native
stage/provenance/lifecycle SQL was **29 passed**. Those precommit files were
committed unchanged; the complete fixed-head executions below are separate.
Current-main client lint had four unused-binding findings; the merged client
has zero, preserving the existing PR69 cleanup.

## Current fixed-head results

| Check | Result |
| --- | --- |
| Complete Python, two workers, 60-second case bound | **{count_text(current['current_counts'])}**, {current['current_records']:,} XML records; {receipts['full-python']['duration_seconds']:.2f}s wall |
| Seven large-capacity cases, separate 600-second bound | **{count_text(report['current_capacity']['counts'])}** |
| Upstream acknowledgement/continuity/startup/container and prototype selection | **{count_text(report['upstream_affected']['counts'])}** |
| All JavaScript/composer/historical-news cases | **{report['javascript']['pass']} passed**, no failures/skips |
| Changed-JavaScript lint | Passed |
| Expanded browser/fixture selection | **{count_text(browser['counts'])}**; actual source-frontend subset **{len(source_cases)} passed** |
| Mobile checks | **87 Node + 66 UI Jest + 21 integration Jest passed**; type/lint/OpenAPI/native-config passed |
| Host production web build; offline mobile JS export | Passed; host Node24.19.0 |
| Node26 production container build/runtime | **Blocked before compilation**: Docker daemon DNS lookup for `auth.docker.io` refused; runtime unrun |
| Deterministic acceptance catalogue | **55 passed**, MemoryStore scope |
| Localization and route audit | **647 messages** across two locales; all **63 required** among 125 application routes |
| Python syntax and whitespace | **556 files parsed**, whitespace passed |

The originally diagnosed target scopes are visible in the same full run:
runtime **{count_text(target_results['lifetime_runtime']['counts'])}**,
read fences **{count_text(target_results['lifetime_reads']['counts'])}**,
transport contracts **{count_text(target_results['postgres_transport_contracts']['counts'])}**,
original-text route variants **{count_text(target_results['original_text_route_variants']['counts'])}**,
and the two legacy phase-read side-effect invariants
**{count_text(target_results['legacy_phase_read_side_effect_invariants']['counts'])}**.
The SQL read assertions snapshot every other public table, verify idempotent phase
initialization and owned-project locking, and retain no-admission/no-generation
and cross-owner checks. RPC failure remains fail-closed. Route fixtures supply
governed publication authority rather than bypassing it. The transport suite's
Apple inspection cases are simulated here and do not claim native Mac coverage.

All database/service inputs were disposable and synthetic. Browser network guards
allowed only the owned loopback frontend/backend, with no external asset hosts or
blocked attempts; unknown backend requests return 503. Ten of the 14 browser
cases use native SQL stage totals; the other four test current workspace/draft
policy through synthetic services. The other 36 cases exercise fixture behavior.
Mobile exports are not native binary/device tests. No live provider performance,
latency SLA or real model quality claim follows from these controlled checks.

## Newly detected and retained failures

The SQL audit `test_public_application_functions_never_raise_serialization_failure`
was passing in the historical b4/51ca run and failed after importing PR68. Native
PostgreSQL now finds exactly `apply_user_memory_events_before_photos(text,jsonb,jsonb)`
with application SQLSTATE `40001`. Migration `202610140007_nonretryable_application_conflicts.sql`
converted earlier application conflicts to `PT409`, but PR68 migration
`202610150003_canonical_stage_readiness.sql` recreates this function with three
`40001` source/event/evidence revision branches. The audit expects zero such
functions and observes one. This is a newly observed upstream SQL contract
regression, not an assumed historical failure. Actual PostgREST HTTP retry
behavior was not measured. The migration and assertion remain intact under the
PR68 ownership boundary; a separate owner repair is needed.

The first integrated head had **5,505 passed / 574 failed / 21 errors / 259 skipped**
in 1,279.42s wall. Compared with the b4 baseline, it added 29 passing SQL cases and
10 browser skips, plus two newly failing cases: the SQL audit above and a 60-second
timeout in the 10,000-receipt case. All seven separately budgeted capacity cases
passed at that head. Their passing correctness run does not waive aggregate
timeouts or establish a capacity/latency SLA.

The first browser selection was **45 passed / 5 failed**: the four retained
identity-fixture failures and the English saved-project resume case, which stayed
at 10% before reload and reached 30% after reload. A focused repeat passed both
languages. The new-head run passed all 14 source cases; the parent also reported
14 passes in independent review of the first head. The original failure remains
archived with its cause unestablished; it is not attributed to baseline, product
or scheduling without proof. Main's five recovery/navigation/turn function
bodies remain byte-identical.

Every current failing assertion is indexed in the JSON, with trace comparisons,
classification evidence and its lossless XML record. No failure is converted to
a pass by matching history. The category counts are:

| Current observed category | Records |
| --- | ---: |
{categories}

The pending-proposal root-authority and outside-composer photo policy-epoch
failures still require explicit contract decisions. Other compatibility drivers
and stale canonical/retired fixtures remain unmet; they were not broadly mocked,
deleted, skipped or admitted through retired execution to turn the suite green.

## Skips and remaining execution limits

All {len(current['skipped'])} aggregate skips are individually indexed with reasons.
The selected browser run covers 14 of the source-frontend skipped cases; it does
not turn the other browser, native opt-in, CLI, plugin or live-model skips into
passes. No provider/live gate or Mac/native-mobile execution was attempted.

| Exact aggregate skip reason | Records |
| --- | ---: |
{skips}

The container failure is environmental: the Docker daemon could not resolve its
anonymous registry-token endpoint before fetching Node26. No owned image/tag or
container exists after that attempt; its temporary Docker config was removed.
Daemon/network/security settings were not changed and no global cleanup was run.
Host builds use Node24 and do not verify the new Node26 runtime image.

All check receipts reconcile their registered native roots/sessions. This is not
a global PID-absence proof. The ordinary timeout test's exact-group observations
retain PID1 zombies as unreaped, rather than claiming running descendants or
claiming successful reaping. Frontend/backend teardown is recorded separately.
Shared Docker build cache is retained; unrelated owners/resources are untouched.

Independent review supplied by the parent covered **523 JS, 14 browser, 146 Python
passes with three retained failures, and 21 lifecycle probes** at the first
`09cd7ad` head against `327b210`, plus 71 allocations/89 roots removed and no
running PostgreSQL in that review's scope. Its raw files are not shared here and
it does not review the new executable head. A subsequent parent-supplied review
of `59086eb` against `400f352` confirmed the inherited SQLSTATE blocker with a
native 4-pass/1-fail gate and direct stale-source RPC, plus another English resume
failure in a 45-pass/5-fail expanded browser run. That review also reported 212
contract, 523 JS, 146 affected Python passes with three retained failures, nine
lifecycle, three native quote-persistence and 14 quote-boundary passes; these
scopes may overlap and are not summed. It reported Node26 standalone builds,
with no container runtime, 63 allocations/78 roots cleaned and browser servers
reaped; full aggregate was unrun and CI empty. Its report/bundle is inaccessible
in this executor. These are supplied findings, distinct from own executions.
Scoped TDD repairs and re-review are now authorized; this checkpoint claims no
repair of either blocker. Earlier parent-reported Mac evidence is historical
and narrower; no new Mac execution is claimed. Human ready status does not waive
any gate or authorize merge/deployment.

## Reviewable raw evidence and provenance

[Complete manifest and every current failed/error/skipped record]({BASE}.json)
and [lossless raw evidence archive]({BASE}.tar.gz) preserve both fixed-head runs,
exact JUnit identities/attributes/problem entries/durations, all raw logs and
receipts, red/green evidence, helper source, argument snapshots, comparisons and
focused probes. Archive: **{package['regular_files']} regular files**, {package['bytes']:,}
bytes, SHA256 `{package['sha256']}`. Every archived member was read back and
matched to its original bytes/hash. There are no redactions. Very long synthetic
image/body parameter IDs are abbreviated only in readable JSON; SHA256 and
zero-based XML testcase indices map them to their complete raw records.

Primary helper hashes were captured before each round, and exact command
snapshots plus post-run hash/HEAD checks are retained. Additional focused/probe
helper versions are archived separately without claiming independent prior hash
snapshots. The earlier historical qualification remains: **the c747/e8 archived
final helper settings differ from eight earlier receipt commands; earlier helper
versions were not supplied.** Their receipts remain authoritative for actual
commands. All 42 historical raw originals still match the independently audited
archive; none was reconstructed or modified. The earlier unverified 647-failure/
275-error aggregate is not used as baseline proof.

No real user data, provider calls, production migration, PR merge, deployment,
credential export, access/security change or external-agent contact occurred.
'''
    (EVIDENCE/(BASE+'.md')).write_text(md)
    print(json.dumps(dict(tested_head=HEAD,current_counts=current['current_counts'],raw_files=package['regular_files'],archive_sha256=package['sha256']),indent=2))

if __name__=='__main__':build()
