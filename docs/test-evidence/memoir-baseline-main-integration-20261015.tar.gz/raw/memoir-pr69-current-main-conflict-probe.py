"""Identify the function found by the retained failing native SQL audit."""
from pathlib import Path
import json,sys
sys.path.insert(0, '/workspace/memoir-baseline/tests')
from test_postgrest_application_conflicts import sql,event_database,private_database,attachment_database,database

def test_identify_current_offending_function(sql):
    raw=sql("select coalesce(json_agg(json_build_object('function',p.proname,'arguments',pg_get_function_identity_arguments(p.oid))), '[]'::json) from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname='public' and p.prokind='f' and p.prosrc ~* 'errcode\\s*=\\s*''40001''';")
    rows=json.loads(raw.stdout)
    result=dict(execution_head='59086ebed443d2b5e3d2fe51a53f462911a2a0c9',offending_functions=rows,
        failing_audit_contract='Zero public application functions may raise SQLSTATE 40001',
        scope='Native disposable PostgreSQL function-source diagnostic. The original audit remains failed; actual PostgREST HTTP retries were not measured.')
    Path('/tmp/memoir-pr69-current-main-conflict-function.json').write_text(json.dumps(result,indent=2)+'\n')
    assert len(rows)==1 and rows[0]['function']=='apply_user_memory_events_before_photos'
