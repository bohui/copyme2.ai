import hashlib,json,subprocess
from pathlib import Path

root=Path('/workspace/memoir-baseline');results=[];helper=Path(__file__);digest=hashlib.sha256(helper.read_bytes()).hexdigest()
for name in ['javascript','javascript-lint','mobile','web-build','mobile-export','browser-standalone','acceptance','localization','routes']:
    with Path('/tmp/memoir-pr69-integration-'+name+'-supervisor.log').open('w') as stream:
        code=subprocess.call(['python','/tmp/run_memoir_pr69_integration_check.py',name],cwd=root,stdout=stream,stderr=subprocess.STDOUT)
    results.append(dict(name=name,supervisor_exit=code))
    Path('/tmp/memoir-pr69-integration-matrix-progress.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps(results[-1]),flush=True)
assert hashlib.sha256(helper.read_bytes()).hexdigest()==digest
